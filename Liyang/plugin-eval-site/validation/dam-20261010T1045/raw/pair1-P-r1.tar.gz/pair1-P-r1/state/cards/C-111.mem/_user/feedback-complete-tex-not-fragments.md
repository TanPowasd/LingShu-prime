---
name: feedback-complete-tex-not-fragments
title: 协作方式：要完整可编译文件，不要片段补丁
description: 用户英文能力不足，任何 .tex 修改都必须输出完整文件，可直接复制保存编译
type: feedback
importance: 8
created: 1791612601785
updated: 1791612601785
---

**Why:** 用户明确说过“我的英文能力不足”“显然我的英语水平不足以修改，我需要你生成完整版本的内容”。片段式修改建议（如“在第 X 行后插入以下代码”）对用户不可用。

**How to apply:**
- 任何 .tex 变更，一律输出**完整文件**，用代码块包裹，可直接复制保存为 `MetaPhysics.tex` 并编译。
- 输出后附一段简短说明：改了哪些地方、为什么改。
- 明确编译指令（如 `pdflatex` 跑两次）。
- 不要要求用户自行定位插入位置或手动拼接代码。
