---
name: project-spacetime-memory-engine
title: 项目：时空记忆引擎（spacetime-memory-engine）
description: 自研语义时空图记忆引擎，Flask Web 接口 + SQLite，集成 CodeGraph 代码域探针
type: project
importance: 8
created: 1791612614132
updated: 1791612614132
---

**时空记忆引擎**（`spacetime-memory-engine`）是荣自研的核心项目：以语义时空图存储/检索记忆，含记录、反思、验证、维生等执行单元。

技术要点：
- 单文件主程序 `spacetime-memory-engine.py`，含 `SpacetimeMemoryEngine`、`CodeGraphAdapter`、`WebInterface` 等类。
- Web 接口基于 Flask，本地端口 **8899**。
- 数据层为 SQLite。

长期目标：发布到 GitHub、参加 B 站公开赛、实现基于隐式学习的多实例「蜂群架构」。
