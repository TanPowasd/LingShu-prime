---
name: project-zenodo-submission-plan
title: 发布计划：Zenodo 优先于 arXiv
description: 因缺乏背书，优先通过 Zenodo 锁定时间戳；arXiv gr-qc 提交需先获 endorsement，暂缓
type: project
importance: 7
created: 1791612608705
updated: 1791612608705
---

## 决策

- **首选 Zenodo**（而非 arXiv），原因是用户为独立研究者，缺乏 arXiv 所需的机构邮箱 + 已有论文作者身份，或领域资深学者的个人背书（endorsement）。
- **arXiv 提交暂缓**：等理论进一步深化后再考虑；目标分类为 **gr-qc**（广义相对论与量子宇宙学）。

## Zenodo 提交前提（已梳理）

1. 注册 Zenodo 账号（可用 GitHub / ORCID 登录）。
2. **强烈建议注册 ORCID iD**（免费，orcid.org，几分钟完成）。
3. 许可证选 **CC BY 4.0**（Zenodo 默认）。
4. 可选：提交到相关 Community。
5. **必须补充参考文献章节**——原 PDF 无 References，已补齐（thebibliography 环境，手写条目，无需 .bib/.bbl）。

## 文件准备

- 论文文件名：`MetaPhysics.tex`，用 `pdflatex` **编译两次**（第二次生成参考文献）。
- 纯英文，无需 XeLaTeX。
- 日期固定为 July 27, 2026。
- 作者脚注含 CTP 说明 + GitHub 仓库链接。

## 已知环境问题

- 用户所在网络连接 GitHub 不稳定（推测美国高峰期），提交时机需择时。
