---
name: reference-ctp-github-repo
title: 外部资源：CTP 公开仓库
description: CTP 协议的 GitHub 仓库链接出现在论文作者脚注中，是推广协议的核心外链
type: reference
importance: 5
created: 1791612601613
updated: 1791612601613
---

- 论文作者脚注中包含 CTP 的 GitHub 仓库链接，作为协议推广的入口。
- 用途：论文中多处（摘要、第 2 节、第 8 节提交建议、脚注）引用该仓库以强调 CTP 的显眼地位。
- 注意：用户所在网络访问 GitHub 偶有不稳定（美国高峰时段）。
- 相关：用户曾与 KIMI 讨论外联策略，KIMI 输出的“协议信号格式（认知校准确认）”文档是本次定位校准的来源。
