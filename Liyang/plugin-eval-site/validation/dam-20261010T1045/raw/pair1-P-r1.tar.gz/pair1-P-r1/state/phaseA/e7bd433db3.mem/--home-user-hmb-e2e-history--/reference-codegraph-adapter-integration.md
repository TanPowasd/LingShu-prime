---
name: reference-codegraph-adapter-integration
title: 参考：CodeGraph 集成踩坑记录
description: CodeGraph 数据库实际表名/列名与适配器假设不符；Windows 下 npm 全局命令 PATH 问题
type: reference
importance: 6
created: 1791612201244
updated: 1791612201244
---

将 **CodeGraph**（npm 包 `@colbymchenry/codegraph`）集成进时空记忆引擎时踩过的坑，后续复用需注意：

1. **必须先索引**：安装后需在项目目录运行 `codegraph index`（或 `codegraph sync`）生成 `.codegraph/codegraph.db`，否则查询报 `no such table`。
2. **实际表名是 `nodes`，不是 `symbols`**；相关表还有 `edges`、`files`、`unresolved_refs`、`nodes_fts` 等。
3. **`nodes` 表列名是 `start_line` / `end_line`**，不是 `line_start` / `line_end`。完整列含 `id, kind, name, qualified_name, file_path, language, start_line, end_line, start_column, end_column, docstring, signature, visibility, is_exported, is_async, is_static, is_abstract, decorators, type_parameters, return_type, updated_at`。
4. **Windows PATH 问题**：npm 全局包目录（`C:\Users\FuRongJun\AppData\Roaming\npm`）常不在 `subprocess` 的 PATH 中，导致 `_check_availability` 误判为未安装；建议用 `shutil.which` 或显式路径检测。
5. **Windows 无 `sqlite3` CLI**，查表结构改用 Python `sqlite3` 模块 + `PRAGMA table_info(...)`。
