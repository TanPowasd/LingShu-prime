---
name: project-license-mit
title: 开源许可证：MIT
description: CommonTrustProtocol 项目采用 MIT 许可证，以最大化生态扩散
type: project
importance: 6
created: 1791612595222
updated: 1791612595222
---

项目决定采用 **MIT 许可证**（2026-08-13 确认）。理由：宽松、社区接受度最高、有利于协议生态扩散；对比 Apache 2.0（专利条款可能劝退部分开发者）与 GPL（传染性阻碍商业采用）。需注意 MIT 不提供专利授权，存在潜在专利风险。
