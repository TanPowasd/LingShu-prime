---
name: protocol-knowledge-layer-write-issue
title: 协议内容未写入知识层的问题
description: 协议理论版已加载到anchor层，但knowledge层缺失protocol_theory_full等三条记录，需检查get_protocol_context
type: project
importance: 6
created: 1791612626649
updated: 1791612626649
---

**问题现象**：长期记忆中 `anchor` 层已成功加载协议理论版（v2.9，约50390字符），但 `knowledge` 层中**没有** `protocol_theory_full`、`protocol_engineering_full`、`specialized_values_full` 三条记录。knowledge 层全是对话历史片段和 fact_extraction 睡眠固化结果。

**后果**：猫娘回答"特化价值观是什么"时凭空生成（"陪着你、拿小鱼干"），未引用协议定义的五个特化价值观（共生优先、结构诚实、共情不盲从、记忆尊严、面向弱者的偏向）。

**排查方向**：`run.py` 的 `_initialize_instances()` 中协议写入知识层依赖 `MemorySystem.get_protocol_context()` 的返回值，需检查该函数是否返回空或加载失败。
