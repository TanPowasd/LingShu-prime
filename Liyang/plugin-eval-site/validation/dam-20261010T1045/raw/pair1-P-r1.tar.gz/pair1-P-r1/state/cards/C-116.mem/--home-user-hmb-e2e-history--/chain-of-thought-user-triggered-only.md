---
name: chain-of-thought-user-triggered-only
title: 思维链仅由用户显式触发
description: "反思/思维链不再自动触发，仅当用户明确要求或消息带 _chain_mode: true 时进入深度推理"
type: feedback
importance: 8
created: 1791612615318
updated: 1791612615318
---

用户确认：日常对话不需要完整思维链，只有明确说“反思一下”或用 `_chain_mode: true` 标记时才进入深度推理流程。

**Why:** 自动触发会增加不必要的开销和延迟，把触发权交给用户更精确可控。

**How to apply:** 默认走设计者快速通道（单次 LLM 调用 + 记忆检索）；`instance.py` 中的链式方法保留但不自动调用，仅在收到明确标记时执行。
