---
name: catgirl-request-source-routing
title: 按调用来源区分猫娘上下文的方案
description: 同一入口识别人类/Codex 调用来源，注入不同系统提示词，而非为 Codex 单独写适配器
type: project
importance: 6
created: 1791612605917
updated: 1791612605917
---

荣提出的方案：不为 Codex 单独写适配器，而是在统一入口（`/message` 或 `/v1/chat/completions`）识别调用来源（请求头或请求体标识），据此注入特化的系统提示词。

- 人类调用 → 温暖自然的对话风格
- Codex 调用 → 输出可解析的命令/JSON 格式

**Why:** 复用现有消息处理链路，保持接口一致性，比维护两套接口更干净。
**How to apply:** 后续扩展调用方（其他 agent/工具）时沿用此模式，优先加来源识别而非新增端点。荣已写入该逻辑。
