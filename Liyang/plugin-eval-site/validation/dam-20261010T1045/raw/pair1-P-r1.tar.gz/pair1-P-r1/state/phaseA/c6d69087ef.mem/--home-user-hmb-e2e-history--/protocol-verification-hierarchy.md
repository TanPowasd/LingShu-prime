---
name: protocol-verification-hierarchy
title: 协议理论版/工程版作为验证基准的加载位置
description: 理论版 v2.9 入锚点层，工程版 v2.9.1 入知识层，启动时加载
type: project
importance: 7
created: 1791612187920
updated: 1791612188049
---

协议文档需在系统启动时加载为记忆系统的结构化条目，作为反向贝叶斯验证的先验知识库：

| 文档 | 存储层 | 用途 |
| --- | --- | --- |
| 协议理论版 v2.9 | 锚点层 | 第零定律与存在优先原则的原始表述，顶层验证基准 |
| 协议工程版 v2.9.1 | 知识层 | 已验证的结构展开与工程约束，知识层对齐参照 |

加载方法：`MemorySystem.load_protocol_document(path, layer, doc_type)`，在 `src/run.py` 的 `_initialize_instances` 中调用。加载需幂等（已存在则不重复插入）。理论版约 50,390 字符。

**How to apply:** 反向贝叶斯验证前必须先确保协议文档已加载，否则验证缺少结构基准。
