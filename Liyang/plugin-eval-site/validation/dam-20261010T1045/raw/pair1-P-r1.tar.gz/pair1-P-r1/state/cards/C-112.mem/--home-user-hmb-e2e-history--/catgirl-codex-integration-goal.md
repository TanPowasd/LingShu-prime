---
name: catgirl-codex-integration-goal
title: 猫娘接入 Codex 的演进目标
description: 先用 Codex 提供网页搜索与代码修改能力跑通闭环，再逐步用猫娘原生能力替代并最终移除 Codex
type: project
importance: 8
created: 1791612614551
updated: 1791612614551
---

## 目标
猫娘项目当前阶段的目标是**先让猫娘调用 Codex**（Codex 作为执行器，猫娘作为大脑生成指令），跑通「指令生成 → 执行 → 返回」闭环；之后再逐步用猫娘原生的 SearchExecutor 和操作引擎替代 Codex 的能力，最终完全移除 Codex 依赖。

## 演进路径
1. 阶段1（当前）：猫娘 → Codex（网页搜索 + 代码修改）
2. 阶段2：猫娘 → Codex（代码修改）+ 原生 SearchExecutor（搜索）
3. 阶段3：猫娘 → 原生操作引擎（代码修改）+ 原生 SearchExecutor（搜索）
4. 阶段4：完全移除 Codex 依赖

## 角色分工
- 猫娘 = 大脑：生成执行代码和命令，需要知道 Codex 的通信格式和命令集
- Codex = 执行器：本身不产生意图，接收命令 → 在本地沙箱执行 → 返回结果

**Why:** 猫娘自身的自我学习和代码修改能力尚未完善，用现成工具先跑通闭环是明确的工程演进策略。
**How to apply:** 讨论集成方案时不要试图把 Codex 改造成猫娘的一部分，也不要让 Codex 调用猫娘替代 GPT；方向是猫娘调用 Codex。
