---
name: project-common-trust-protocol
title: 项目：CommonTrustProtocol 仓库与 aeis 工程
description: GitHub 仓库 FuRongJun-1999/CommonTrustProtocol，含协议理论 + aeis 灵枢工程实现 v0.3.0
type: project
importance: 8
created: 1791612198328
updated: 1791612198328
---

项目仓库：https://github.com/FuRongJun-1999/CommonTrustProtocol

结构：
- 协议理论版与工程规范（智能论 v3.2）
- `aeis/` 灵枢 AEIS 工程实现（Python 库 + MCP + 蜂群协作层），v0.3.0 已于 2026-08-13 开源发布
- 猫娘计划（协议在猫娘条件空间下的交互接口投影）

引擎基线：时空记忆图 v1.11 + 自我认知循环 v1.12。
