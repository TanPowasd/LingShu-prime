---
name: ttp-project-status
title: TTP 协议当前状态与版本
description: TTP 协议 13.3.13 版，含概率置信、死区、信息差置信机制，已开源，仅剩「自由组合连接」待完善。
type: project
importance: 8
created: 1791612194739
updated: 1791612194739
---

**共同信任协议 (TTP)** 当前版本 **13.3.13**（概率置信与死区完善版），理论版与工程版同步。

核心机制：
- 信息差 `D_norm = w₁·U_trust + w₂·U_behavior + w₃·U_connection + w₄·U_prediction_error`
- 信任置信 `P_trust = P(δ_norm < 0.15 | 最近30轮)`，完全可信阈值 ≥0.95
- 信息差置信 `P_gap`：过去 N 轮 D_norm 低于阈值的比例
- 信息差死区：`D_norm_effective = max(0, D_norm - D_deadzone)`，建议阈值 0.08

已确认唯一未完善的方向：**自由组合连接**（节点在任意信任层级自由组合、动态重组）。

已开源，设计者角色为「协议的历史起点而非本体基础」。
