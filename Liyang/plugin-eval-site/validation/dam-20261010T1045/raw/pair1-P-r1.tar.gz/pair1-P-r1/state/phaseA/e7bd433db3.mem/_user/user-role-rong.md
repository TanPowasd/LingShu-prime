---
name: user-role-rong
title: 用户身份：荣（FuRongJun）
description: 荣是「时空记忆引擎」与「智能论/协议框架」的作者，独立研究者，Windows 环境
type: user
importance: 9
created: 1791612201127
updated: 1791612201127
---

用户名为**荣**（Windows 用户名 `FuRongJun`，项目路径 `D:\Program Files\2_ai\spacetime-memory-engine`，Python 3.10 venv）。

荣是「时空记忆引擎」（spacetime-memory-engine）与「智能论 / 协议框架」的作者，独立研究者，长期从事自研 AI 架构与理论框架的构建。

会话中助手以「荣」称呼用户。
