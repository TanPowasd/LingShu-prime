---
name: protocol-kernel-performance-tuning
title: 内核响应性能调优：关闭思维链与异步保存
description: 内核已关闭DeepSeek reasoning_effort、异步保存对话历史，一次完整对话约10秒需注意客户端超时配置
type: project
importance: 6
created: 1791612626588
updated: 1791612626588
---

**性能瓶颈与优化**（run.py / src/osi/drivers/llm.py）：

1. **关闭 DeepSeek 思维链**：在 `LLMAdapter` 中设置 `reasoning_effort="low"`，控制模型内部推理深度（区别于协议的多实例思维链，后者早已关闭）。
2. **异步保存对话历史**：`/message` 端点中对话保存改为后台异步提交，不阻塞响应返回。

**耗时构成**：反向贝叶斯验证 ~1s + 记忆检索 ~0.5s + LLM推理 ~3-5s + 保存历史 ~2s ≈ 10.8s。

**注意**：猫娘身体层默认请求超时 10 秒，刚好卡在边界导致超时，需将客户端超时延长至 30-60 秒。
