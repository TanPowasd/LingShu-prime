---
name: project-xiaoying-socrates-system
title: 小萤与苏格拉底AI教育系统
description: 基于共信主义的乡村教育AI系统，包含苏格拉底（引导者）与小萤（8岁学习伙伴）双角色，FastAPI+DeepSeek实现
type: project
importance: 8
created: 1791612194867
updated: 1791612194867
---

项目是一个乡村教育AI系统，核心使命是'消灭信息差'。包含两个角色：**苏格拉底**（教育引导者，用提问/类比/可视化引导学生）和**小萤**（8岁乡村小学生，向老师学习并反思成长）。技术栈：FastAPI后端，DeepSeek-R1模型（deepseek-reasoner），前端index.html。已实现功能：独立记忆系统（conversations_socrates / conversations_xiaoying 目录隔离）、梦境机制、孤独反思、社交网络。曾因共享记忆导致苏格拉底风格混淆（模仿小萤童真语气），最终通过**独立记忆系统**解决。
