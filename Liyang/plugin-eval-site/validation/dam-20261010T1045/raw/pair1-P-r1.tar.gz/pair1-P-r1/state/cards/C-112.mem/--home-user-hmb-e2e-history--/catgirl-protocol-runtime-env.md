---
name: catgirl-protocol-runtime-env
title: 猫娘协议运行环境与项目路径
description: 项目位于 D:\Program Files\1_ai\catgirl-protocol-interface，用 chromadb +
  sentence_transformers
type: project
importance: 5
created: 1791612607529
updated: 1791612607529
---

## 运行环境

- **项目路径**：`D:\Program Files\1_ai\catgirl-protocol-interface`
- **核心文件**：`instance.py`（单元实现，含 Flask 路由与角色分支）、`run.py`（代理路由）
- **技术栈**：Flask + chromadb（向量库 `_collections`）+ sentence_transformers（`_embedding_model`）
- **HF 镜像**：代码中设置 `os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'`
- **角色初始化**：仅 `role=record` 时初始化向量数据库与 collections；仅 `role=reflection` 时设置 `record_port`。同一 `instance.py` 按角色注册不同端点。
- **目录结构**：`src/core/instance.py`（项目根需向上两级）
