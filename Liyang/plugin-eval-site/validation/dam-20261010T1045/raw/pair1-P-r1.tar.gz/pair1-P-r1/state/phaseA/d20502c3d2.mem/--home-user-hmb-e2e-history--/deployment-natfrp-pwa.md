---
name: deployment-natfrp-pwa
title: 部署方案：SakuraFrp内网穿透 + PWA
description: 用户选择SakuraFrp（natfrp.com）做内网穿透分享系统，计划后续添加PWA支持
type: reference
importance: 5
created: 1791612194953
updated: 1791612194953
---

用户使用 **SakuraFrp**（https://www.natfrp.com/）进行内网穿透，将本地FastAPI服务（端口8000）暴露到公网供朋友测试。隧道配置：TCP类型，本地IP 127.0.0.1，本地端口8000，选择国内节点。

**部署优先级**：先内网穿透（解决'能否访问'），后添加PWA（解决'体验好不好'）。PWA只需在index.html中添加manifest.json和service-worker.js即可。

**已知问题**：朋友测试时提出千奇百怪的问题（非预设教学问题），需要苏格拉底具备'转化器'能力——不拒绝任何问题，但将对话引向认知探索。
