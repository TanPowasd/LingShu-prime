---
name: memory-caching-paper-reference
title: "参照论文《Memory Caching: RNNs with Growing Memory》"
description: 谷歌 2026-02 论文，分段-缓存-检索机制，作为协议记忆系统（情境层/睡眠固化）的工程规划参照
type: reference
importance: 6
created: 1791612611540
updated: 1791612611540
---

《Memory Caching: RNNs with Growing Memory》（Google，2026-02）是协议框架记忆系统的下一步规划参照。

核心机制：把长序列切成片段，每段处理完冻结记忆状态存入缓存池，处理新片段时对存档发起检索。聚合策略包括门控残差记忆（GRM）、稀疏选择性缓存（SSC）。

与协议的对应：MC 缓存快照 ≈ 情境层；分段间隙存档 ≈ 睡眠状态的情境层固化；缓存索引 ≈ 以时间片段为节点的可检索图结构。

注意：工程文档需显式声明 MC 原始参数不可直接套用协议 v2.9 的条件空间。
