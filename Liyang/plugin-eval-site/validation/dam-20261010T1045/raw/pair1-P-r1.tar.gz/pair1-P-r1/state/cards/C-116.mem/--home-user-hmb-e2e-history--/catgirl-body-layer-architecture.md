---
name: catgirl-body-layer-architecture
title: 猫娘身体层架构与问题定位
description: 猫娘身体层是协议实例的外部接入层，通过OpenAI兼容接口调用内核；其System Prompt会覆盖协议约束
type: project
importance: 7
created: 1791612626525
updated: 1791612626525
---

**猫娘身体层**是协议在特定条件空间下的接口投影（3.14节猫娘计划），本质是前端/客户端，通过 `http://localhost:8000/v1`（OpenAI兼容接口）调用内核协议实例。

**分层结构**：
- 内核层：`/message` 端点，协议理解与记忆检索
- API层：`/v1/chat/completions`，OpenAI兼容代理，转发到 `/message`
- 身体层：猫娘前端，使用 AsyncOpenAI/Python 2.8.1 发送请求

**关键发现**：身体层会注入自己的 `role: system` 消息（如 "YUI角色扮演"），会覆盖/稀释内核的协议系统提示词，导致协议价值观被绕过。修复方向是合并身体层 System Prompt 与协议约束，协议价值观作为上层约束，并让反向贝叶斯验证整个合并后的请求。
