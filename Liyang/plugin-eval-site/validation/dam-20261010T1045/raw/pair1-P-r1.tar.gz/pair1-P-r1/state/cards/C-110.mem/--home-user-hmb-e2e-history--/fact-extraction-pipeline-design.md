---
name: fact-extraction-pipeline-design
title: 事实抽取管道的完整流程设计
description: 对话→条件空间识别→结构化抽取→反向贝叶斯验证→存入知识层
type: project
importance: 7
created: 1791612588929
updated: 1791612588929
---

事实抽取管道的完整流程：

```
输入文本
  → 条件空间识别（输出单元 + LLM）
  → 反向贝叶斯验证（第零定律一致性 / 锚点层·结构层历史参照 / 知识层已有结构对齐）
  → 通过：存入知识层（verified: true）
  → 未通过：存入知识层（verified: false，待验证）
```

涉及文件：
- `src/osi/kernel/output.py`：`extract_fact` 方法，整合条件空间识别与结构化抽取
- `src/osi/kernel/memory.py`：`store_fact` 方法，存储事实并标记验证状态
- `src/osi/kernel/verify.py`：反向贝叶斯验证逻辑

端点：`/fact/extract`（POST），`/fact/condition/identify`（POST）。

**How to apply:** 若 LLM 不可用或验证不通过，回退到「待验证」状态而非丢弃内容。
