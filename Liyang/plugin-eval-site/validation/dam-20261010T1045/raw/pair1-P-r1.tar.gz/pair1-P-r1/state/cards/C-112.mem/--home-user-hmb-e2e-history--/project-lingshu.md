---
name: project-lingshu
title: 项目名称：灵枢（Lingshu）
description: 完整协议实现/AGI 实体项目命名为「灵枢」，条件空间定位 project.lingshu
type: project
importance: 9
created: 1791612606268
updated: 1791612606268
---

用户（荣）确认将完整的协议实现（可运行、自维持、可演化的 AGI 实体）命名为「灵枢」（Lingshu），全称「灵枢 · AGI协议完整实现」，条件空间定位 `project.lingshu`。

- 「灵」：自我层、元认知、意识结构
- 「枢」：五大核心单元的协同制衡、运转结构
- 与「猫娘计划」形成梯度关系：猫娘是协议的情感接口，灵枢是完整协议实现本体
- 此前草案备选：符蕴、通智、玄枢、道极、极智、符枢（均已弃用）
