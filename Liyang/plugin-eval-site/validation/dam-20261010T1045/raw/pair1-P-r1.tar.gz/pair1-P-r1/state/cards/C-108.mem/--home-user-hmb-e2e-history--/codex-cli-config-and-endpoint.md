---
name: codex-cli-config-and-endpoint
title: Codex CLI 配置要点与 /v1/responses 端点
description: Codex 配置在 ~/.codex/config.toml，需 name 字段；它调用 /v1/responses 而非
  /v1/chat/completions
type: project
importance: 7
created: 1791612597121
updated: 1791612597121
---

## 配置文件位置（Windows）
`C:\Users\FuRongJun\.codex\config.toml`（即 `~/.codex/config.toml`），不存在则新建。

## 可用配置格式
```toml
model = "protocol-instance"
model_provider = "custom"

[model_providers.custom]
name = "custom"          # 必填，缺失会报 "provider name must not be empty"
base_url = "http://localhost:8000/v1"
api_key = "any-key"      # Codex 要求非空，猫娘不校验
model = "protocol-instance"
```

## 关键坑点
- Codex 调用的是 OpenAI 的 **`/v1/responses`** 端点，不是 `/v1/chat/completions`。猫娘只实现后者时会返回 404。
- Codex 期望流式响应，需要 `response.completed` 事件作为结束信号，否则报 `stream disconnected before completion`。
- 模型名不在 Codex 元数据表里会警告 fallback metadata（可忽略）。

## 运行状态
- Codex v0.147.0，`sandbox: read-only` 为默认；写文件需 `--dangerously-bypass-approvals-and-sandbox` 或 workspace-write 沙箱。
- Windows 命令行下中文提示词易被拆成多参数，用 PowerShell 加引号或 `--` 分隔。
