---
name: memory-layers-type-unification
title: MemorySystem._layers 条目类型必须统一为 MemoryEntry
description: 不要在各访问点做防御式类型检查，应统一数据结构
type: feedback
importance: 6
created: 1791612581041
updated: 1791612581041
---

`MemorySystem._layers` 中的条目类型长期不统一（来自 `record_instance._memory` 的是 dict/str，来自 `store()` 的是 `MemoryEntry` 对象），导致 `load_protocol_document` 等处以 `entry.get(...)` / `entry.content` 访问时反复抛 `AttributeError: 'str' object has no attribute 'get'`，同类错误连续出现三次。

**Why:** 在每一处访问点做防御式类型检查只是补丁，无法根治；问题根源是数据结构本身混乱。

**How to apply:** 统一 `_layers` 的数据结构为 `MemoryEntry`，在数据入口处（如从 `record_instance._memory` 同步时）完成转换，而不是在每次读取时判断类型。
