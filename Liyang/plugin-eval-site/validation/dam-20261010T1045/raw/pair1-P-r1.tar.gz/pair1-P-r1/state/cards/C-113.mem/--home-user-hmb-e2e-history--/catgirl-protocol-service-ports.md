---
name: catgirl-protocol-service-ports
title: 猫娘协议实例端口与路由约定
description: 统一代理 8000，记录单元 8001，反思单元 8002；/memory/all 供跨单元全量读取
type: project
importance: 6
created: 1791612610181
updated: 1791612610181
---

## 服务端口与路由

- **统一对外代理**：`http://localhost:8000`（`run.py`，仅负责路由转发，不参与内部决策）
- **记录单元**：8001
- **反思单元**：8002

**路由映射**：
- `/memory/*` → 记录单元（8001）
- `/sleep/batch_decay` → 记录单元（批量衰减）
- `/sleep/random_associate` → 记录单元（联想功能）
- `/sleep/validate` → 验证单元（结构化筛选）

**关键端点**：
- `GET /memory/all?layer=<layer>`（仅记录单元，其他角色返回 403）：返回指定层级全部记忆，结构为 `{"<layer>": [...]}`。用于绕开 `/memory/search` 空查询不返回条目的限制。
- `POST /memory/search`：语义检索，默认阈值 0.5；跨层（情境↔知识）相似度天然偏低，用高阈值会筛掉有效跨层关联。
- `GET /memory/summary`：返回各层计数与角色。

**数据层级**：anchor / context / knowledge / self / structure。
