---
name: ref-gliding-horse
title: 外部参考：流马（Gliding Horse）
description: Rust 构建的 AI Agent 操作系统，PDCA 调度 + JSON-LD 语义图谱 + 代码级系统调用门
type: reference
importance: 5
created: 1791612611669
updated: 1791612611669
---

流马（Gliding Horse），用 Rust 构建的 AI Agent 操作系统。GitHub: https://github.com/doiito/gliding_horse

核心机制：动态 PDCA 调度、JSON-LD 语义图谱（L2 Blackboard 长期上下文，图结构存储）、代码级系统调用门（运行时硬性约束 Agent 行为），目标是把记忆/技能/知识变为可追溯、可审计的工程资产。

与协议框架的对应：PDCA 闭环 ≈ 3.10 节自迭代闭环；L2 Blackboard 图结构 ≈ 知识层 + 条件空间识别卡。在协议视角下被视为工程层对“自维持结构”硬性约束的实践。
