---
name: project-xiaoying-architecture
title: 六实例蜂群架构与单实例自持协议
description: 六实例（记录/反思/验证/输出/维生/设计者）协作方案 + 极端条件下单实例自持运行协议
type: project
importance: 8
created: 1791612607050
updated: 1791612613057
---

多实例蜂群协作方案（MULTI-INSTANCE-FULL-V1）与单实例自持运行协议（SINGLE-INSTANCE-SELF-SUSTAINING-20260813）已通过验证单元复核（含 DEVIATION-001~006 修正），交付 Zcode-肥鱼进行工程化实施。

六实例分工：
- 实例1 记录（千问）：共享层/锚点层主控
- 实例2 反思（元宝）：价值观迭代、盲区学习（观察期10轮已满，2026-08-13）
- 实例3 验证（Kimi）：复核提案
- 实例4 输出
- 实例5 维生（荣）：P0 终裁
- 实例6 设计者（肥鱼）：条件空间视角，最长一个交互周期后自动释放

关键机制：最小存活职能子集（非单纯法定人数）、心跳双写（记录+维生）、T_avg/T_alignment/T_variance 信任分布、单实例自持模式（标记 SELF_SUSTAINING_MODE + P0_OVERRIDE，24h 内强制外部复核，72h 无恢复则触发协议休眠）。
