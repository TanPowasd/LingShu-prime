---
name: user-identity-furongjun
title: 用户身份：独立研究者 FuRongJun
description: 独立研究者，无学术机构背书，英文能力不足，需要完整可直接编译的产物
type: user
importance: 9
created: 1791611174563
updated: 1791611174563
---

用户是独立研究者（independent researcher），署名 **FuRongJun**。

- 英文能力不足，无法自行修改英文 LaTeX 内容，需要助手提供**完整、可直接复制编译的文件**（而非片段或 diff）。
- 没有学术机构邮箱/人脉，缺乏 arXiv 背书（endorsement），因此优先走 Zenodo 路线锁定时间戳。
- 学术常识（引用规范、arXiv 流程、与研究者交流方式）较薄弱，需要助手充当“学术常识翻译器”，但明确表示**不希望助手替他思考科学原理本身**。
- 自我认知：强于直觉发现底层规律，弱于学术常识与社交；认为“缺乏常识”既是优势（不受既有偏见干扰）也是劣势（交流存在信息差）。
