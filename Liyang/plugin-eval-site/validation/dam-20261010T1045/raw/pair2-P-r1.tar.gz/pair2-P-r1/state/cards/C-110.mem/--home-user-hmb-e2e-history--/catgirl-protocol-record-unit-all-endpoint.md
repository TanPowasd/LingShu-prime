---
name: catgirl-protocol-record-unit-all-endpoint
title: 记录单元 /memory/all 端点
description: '记录单元新增全量读取端点，返回 {"<layer>": [...]}，供其他单元只读访问'
type: project
importance: 6
created: 1791611517665
updated: 1791611517665
---

记录单元新增 `/memory/all?layer=<layer>` 端点（仅 role=record 可用，否则返回 403），返回该层级全部记忆数据的完整字段（base_weight、decay_rate、id、last_access、metadata、timestamp、trigger_count、weight）。

返回结构为 `{"context": [...]}` / `{"knowledge": [...]}` 等，调用方应使用 `data.get("context", [])` 提取。

**Why:** 原 `/memory/search` 在查询为空时不返回任何条目，无法获取全部情境层数据。

**How to apply:** 需要全量记忆数据时调用 `/memory/all`，不要用空查询调 `/memory/search`。
