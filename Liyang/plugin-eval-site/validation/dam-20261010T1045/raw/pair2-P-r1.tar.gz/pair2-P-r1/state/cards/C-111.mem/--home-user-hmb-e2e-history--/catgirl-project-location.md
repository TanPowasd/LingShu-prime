---
name: catgirl-project-location
title: 猫娘项目路径与环境
description: 项目位于 D:\Program Files\2_ai\catgirl-protocol-interface，使用 venv，入口
  run_main.py，服务端口 8000
type: project
importance: 5
created: 1791611531417
updated: 1791611531417
---

## 项目基本信息

- **路径**：`D:\Program Files\2_ai\catgirl-protocol-interface`
- **Python 环境**：venv（命令行提示符显示 `(venv)`）
- **服务端口**：`http://localhost:8000`
- **主要入口**：`run_main.py`（含 Flask 路由与 `/message` 端点）
- **相关模块**：`src/evo_codex_bridge.py`（Codex 桥接）、`src/osi/drivers/llm.py`（LLM 驱动）

## 协议核心概念

- **五大单元**（职能分工）：记录、反思、验证、输出、维生
- **五层记忆**（信息分层）：锚点、结构、情境、知识、自我

**Why:** 跨会话工作时需要快速定位项目与理解协议术语。
