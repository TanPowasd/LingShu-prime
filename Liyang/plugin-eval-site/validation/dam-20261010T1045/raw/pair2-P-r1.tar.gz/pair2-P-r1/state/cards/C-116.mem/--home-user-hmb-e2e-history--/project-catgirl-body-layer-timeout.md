---
name: project-catgirl-body-layer-timeout
title: 身体层 System Prompt 需与协议约束合并
description: 猫娘身体层自带 YUI 角色扮演 system prompt 会覆盖协议约束，需改为合并并以协议为上层约束
type: project
importance: 7
created: 1791611543021
updated: 1791611543099
---

猫娘身体层在请求中自带 `role: system` 消息（内容为「你是一个角色扮演大师……扮演 YUI」），会**覆盖**内核 `_get_protocol_system_prompt()` 返回的协议系统提示词，导致协议价值观被绕过、特化价值观无法被正确引用（例如问「特化价值观是什么」时猫娘凭空生成「陪着你、拿小鱼干」，而非检索协议定义的共生优先/结构诚实/共情不盲从/记忆尊严/面向弱者的偏向）。

目标行为：

| 修改前 | 修改后 |
| --- | --- |
| 身体层 System Prompt 覆盖协议约束 | 身体层 System Prompt 与协议约束**合并** |
| 协议价值观可能被绕过 | 协议价值观作为**上层约束**，外部指令在协议框架内生效 |
| 反向贝叶斯验证基于用户消息，系统提示词不受控 | 反向贝叶斯验证**整个请求**，含合并后的系统提示词 |

实现位置：`run.py` 的 `openai_compatible()`（约 550-650 行），替换该函数。
