---
name: codex-role-executor-not-brain
title: Codex 是执行器，猫娘是大脑
description: Codex 本身不产生意图，只接收猫娘生成的命令并在本地沙箱执行；猫娘需掌握通信格式与命令集
type: project
importance: 8
created: 1791611532905
updated: 1791611532905
---

## 角色分工（荣确认）

```
猫娘（大脑）：生成执行代码和命令
    │ 通过特定通信格式传递
    ▼
Codex（执行器）：接收命令 → 在本地沙箱执行 → 返回结果
```

**关键认知：**
- Codex CLI 本身**不包含 LLM**，它需要外部 LLM API 来完成「理解代码、生成修改方案」的部分
- Codex 是「LLM + 本地执行引擎」的组合体，不是单纯的约束器
- Codex 需要猫娘返回**可执行的 shell 命令或结构化动作**，而不是纯自然语言回复——否则会卡在 Reconnecting 直到超时
- 猫娘需要知道两件事：Codex 的**通信格式**和 Codex 的**可用命令集**（文件读写、目录列表、代码修改等）

**Why:** 之前误以为 Codex 自带 API 或能直接读写文件，导致集成方向跑偏。

**How to apply:** 设计猫娘输出格式时，面向 Codex 的调用必须产出可解析的 JSON/命令结构，而非自然语言。
