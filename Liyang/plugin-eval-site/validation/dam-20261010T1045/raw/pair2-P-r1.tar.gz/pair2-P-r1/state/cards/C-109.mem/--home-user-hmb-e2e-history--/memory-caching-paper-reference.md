---
name: memory-caching-paper-reference
title: 参照论文：Memory Caching (Google, 2026-02)
description: "《Memory Caching: RNNs with Growing Memory》作为情境层工程化的技术参照与下一步规划依据"
type: reference
importance: 6
created: 1791611517322
updated: 1791611517322
---

**《Memory Caching: RNNs with Growing Memory》**（Google，2026年2月）——荣确认作为下一步规划参照。

核心机制：分段压缩 → 存档检查点（冻结隐藏状态入缓存池）→ 跨段检索。聚合策略包括门控残差记忆（GRM）与稀疏选择性缓存（SSC）。

与协议框架的对应：
- MC 的历史「快照」≈ 协议的情境层。
- MC 的分段存档 ≈ 睡眠状态中对情境层的结构化筛选与固化到知识层。
- MC 的缓存索引 ≈ 以时间片段为节点的可检索图结构。

**注意**：MC 原始参数不可直接套用，需在工程文档中显式声明条件空间差异。
