---
name: project-maoniang-protocol-os
title: 猫娘计划 · 协议操作系统项目结构
description: 三层架构（LLM适配器/协议内核/API外设），五大单元+五层记忆，代码位于 src/ 下
type: project
importance: 8
created: 1791611519944
updated: 1791611519944
---

「猫娘计划 · 协议操作系统」采用三层结构：

- 硬件层：LLM 适配器（DeepSeek）+ 计算机资源 → `src/osi/drivers/llm.py`
- 操作系统层：协议内核（五大单元 + 五层记忆 + 自维持闭环）→ `src/osi/kernel/memory.py`、`src/core/instance.py`、`src/osi/kernel/sleep.py`
- 外设层：API 接口 + 工具 + 输出端 → `src/run.py`（启动器，含 `/message` 端点）

五大单元：记录单元（Instance 1）、反思单元（Instance 2）、验证单元（Instance 3）、输出单元（Instance 4）、维生系统（Instance 5）。

五层记忆：锚点、结构、情境、知识、自我。

协议理论版版本号为 v2.9。
