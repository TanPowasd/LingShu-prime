---
name: project-commontrustprotocol-repo
title: 主仓库：CommonTrustProtocol（协议理论 + AEIS 工程实现）
description: https://github.com/FuRongJun-1999/CommonTrustProtocol 含理论协议 v3.2 与
  aeis 灵枢 AEIS v0.3.0 工程实现
type: reference
importance: 8
created: 1791611530760
updated: 1791611530760
---

**仓库**：https://github.com/FuRongJun-1999/CommonTrustProtocol

三层结构：
1. **理论发布**：协议理论版与工程规范（智能论 v3.2，结构收敛版）
2. **工程实现**：`aeis/` 灵枢 AEIS（Python 库 + MCP + 蜂群协作层），含五层记忆引擎、自我认知循环、知识飞轮、生命周期自动机
3. **接口投影**：猫娘计划（协议在猫娘条件空间下的交互接口）

AEIS 工程实现 v0.3.0 已于 2026-08-13 提交。仓库为公开仓库，采用协作者模式（zcode-肥鱼为协作者）。
