---
name: project-license-mit
title: 项目开源许可证：MIT
description: CommonTrustProtocol 项目确定采用 MIT 许可证，以最大化生态扩散
type: project
importance: 6
created: 1791611528746
updated: 1791611528746
---

项目开源许可证确定为 **MIT**。理由：最大化生态扩散，允许自由使用/修改/闭源商用，仅要求保留版权声明；相比 Apache 2.0 更简洁、社区接受度更高；相比 GPL 无传染性，利于商业采用。DeepSeek 后续版本也从自定许可证改为 MIT。需注意的潜在风险：专利保护缺失。
