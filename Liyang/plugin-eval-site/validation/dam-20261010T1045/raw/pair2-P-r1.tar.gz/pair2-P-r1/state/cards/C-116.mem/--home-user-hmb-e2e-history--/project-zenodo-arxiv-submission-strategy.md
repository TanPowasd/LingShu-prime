---
name: project-zenodo-arxiv-submission-strategy
title: 发布策略：先 Zenodo，arXiv 待时机
description: 因缺乏背书优先提交 Zenodo 锁定时间戳；arXiv gr-qc 提交需 endorsement，暂缓
type: project
importance: 7
created: 1791611527181
updated: 1791611527181
---

发表策略与外部资源：

- **Zenodo 优先**：因用户是独立研究者、缺乏 arXiv 背书，先提交 Zenodo 锁定时间戳。提交前需：注册 Zenodo 账号（可用 ORCID/GitHub 登录）、注册 ORCID iD（强烈建议）、选择许可证 **CC BY 4.0**（默认）、可选加入社区。
- **arXiv 暂缓**：目标分类为 **gr-qc**（广义相对论与量子宇宙学）。首次提交需 endorsement；2026 年 1 月 21 日起新规则要求：①机构邮箱 + 已是 arXiv 论文作者（自动背书），或 ②找 gr-qc 领域资深 arXiv 作者个人背书。arXiv 要求提交可编译的 LaTeX 源文件（非仅 PDF），若用 BibTeX 需附 `.bbl`；若用 `thebibliography` 环境则只需 `.tex`。
- **外联策略**：不发送“请评审我的大统一理论”，而是邀请研究者评估“由元协议约束的理论构建方式”能否为其领域提供新组织视角。潜在接触对象：Bianconi（熵引力）、Chakchaev（QIR）、Verlinde（熵引力）。
- 用户倾向：先继续理论深化，邮件外联“等完成继续的理论深化了解也不迟”。
