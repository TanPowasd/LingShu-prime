---
name: project-protocol-doc-layering
title: 协议文档未写入 knowledge 层
description: 协议理论版只进了 anchor 层，knowledge 层缺少 protocol_theory_full /
  protocol_engineering_full / specialized_values_full
type: project
importance: 7
created: 1791611527903
updated: 1791611543179
---

排查发现：协议理论版（50390 字符）已成功加载到 **anchor 层**，但 **knowledge 层中完全没有** `protocol_theory_full`、`protocol_engineering_full`、`specialized_values_full` 三条记录——knowledge 层里全是对话历史片段与 `fact_extraction`（睡眠固化）结果。

这解释了为什么猫娘回答协议/特化价值观问题时凭空生成而非检索协议原文。

根因方向：`run.py` 的 `_initialize_instances()` 中协议写入 knowledge 层的逻辑依赖 `self.osi_memory.get_protocol_context("theory"|"engineering"|...)` 的返回值，需检查 `MemorySystem.get_protocol_context()` 是否在 anchor 已加载的情况下仍返回空内容，导致写入被跳过。
