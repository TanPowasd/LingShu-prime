---
name: catgirl-codex-integration-goal
title: 猫娘接入 Codex 的演进目标
description: 先让猫娘调用 Codex 的网页搜索与代码修改能力跑通闭环，再逐步用原生模块替代并移除 Codex 依赖
type: project
importance: 9
created: 1791611196816
updated: 1791611196816
---

## 目标：先用起来，再逐步替代

荣明确了接入 Codex 的工程演进路径：

1. **阶段1（当前）**：猫娘 → Codex（网页搜索 + 代码修改），把「意图→搜索→修改→验证」闭环跑通
2. **阶段2**：猫娘 → Codex（代码修改）+ 原生 SearchExecutor（搜索）
3. **阶段3**：猫娘 → 原生操作引擎（代码修改）+ 原生 SearchExecutor（搜索）
4. **阶段4**：完全移除 Codex 依赖

**Why:** 猫娘自身的自我学习和代码修改能力尚未完善，接入 Codex 是为了先用现成能力把闭环跑通，而不是把 Codex 改造成猫娘的一部分。

**How to apply:** 讨论 Codex 集成时不要偏离这个方向——不要试图让 Codex 调用猫娘替代 GPT，而是让猫娘调用 Codex。任何方案都应服务于「最终移除 Codex 依赖」这一终点。
