---
name: xiaoying-socrates-system
title: 小萤与苏格拉底 AI 教育系统
description: 基于共信主义实现的双 AI 教育系统，含记忆隔离、梦境/孤独反思、社交网络等机制
type: project
importance: 7
created: 1791611525730
updated: 1791611525730
---

用户实现的双 AI 教育系统，基于 FastAPI + DeepSeek（deepseek-reasoner）构建：

- **苏格拉底**：引导者角色，使命是「消灭信息差」，用提问/类比/可视化引导学生自己发现答案。
- **小萤**：8 岁乡村小学生 AI，向老师学习，具备记忆、梦境、孤独反思、社交网络（xiaoying_life / xiaoying_social）。

**关键架构决策**：
- 苏格拉底与小萤使用**独立的对话历史存储**（conversations_socrates / conversations_xiaoying），因为共享上下文会导致苏格拉底角色风格漂移（误判提问者身份）。
- 共享的是全局知识/信息，隔离的是角色目标与对话历史。

**部署进度**：已用 SakuraFrp 做内网穿透供朋友测试；PWA 支持待内网穿透完成后添加。
