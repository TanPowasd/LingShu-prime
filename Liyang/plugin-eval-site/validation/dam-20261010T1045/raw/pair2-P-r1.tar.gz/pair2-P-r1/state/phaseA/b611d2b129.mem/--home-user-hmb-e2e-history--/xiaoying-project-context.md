---
name: xiaoying-project-context
title: 小萤项目：乡村教育 AI 的持续成长自主反思系统
description: 用户正在开发'小萤'——一个面向乡村教育的、持续成长的自主反思型 AI 学习伙伴。
type: project
importance: 8
created: 1791611178214
updated: 1791611178214
---

用户正在开发名为**小萤**的乡村教育 AI 系统。核心设计：

- **双角色架构**：苏格拉底（教学者，成熟教学协议，通过生成对抗网络训练出经验规范，可直接注入系统提示词保证价值观一致）与小萤（学习者，持续成长的自主反思系统）。二者本质上是同一个 AI。
- **小萤的定位**：适用于'孩子向小萤教学'的场景，对情感识别、回应、理解有较高要求。目标是具有'存在感'——像真实成长中的小朋友。
- **代码库**：包含 main.py、训练脚本、小萤的生命系统（xiaoying_life.py，Memory 对象列表）、社交记忆系统（xiaoying_social.py，ExtendedXiaoyingLife，memories 为 dict 列表）。
- **关键机制**：长期记忆（含 importance 权重与分层存储）、自我反思（SELF_REFLECTION_PROMPT）、梦境机制（空闲时重估记忆、可能微调价值观）、孤独状态（恐惧消化、信任巩固）、信任分数 trust_score。
- **已知技术坑**：ExtendedXiaoyingLife.memories 是 dict 列表，需用 `m['importance']` 而非 `m.importance`；socrates 模式下 xiaoying 变量未初始化会导致 UnboundLocalError。
