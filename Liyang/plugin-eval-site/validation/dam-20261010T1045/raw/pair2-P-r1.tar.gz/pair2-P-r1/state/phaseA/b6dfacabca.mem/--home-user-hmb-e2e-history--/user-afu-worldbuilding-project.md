---
name: user-afu-worldbuilding-project
title: 阿符的创作项目：陈默与陈星的世界
description: 用户阿符正在构建包含月球基地、生存、探索要素的虚构故事，核心概念为「熵噪壁」与「火种计划」
type: project
importance: 8
created: 1791611190849
updated: 1791611190849
---

用户（阿符）长期在构建一个虚构故事世界，核心角色为陈默与陈星，涉及月球基地、生存、探索等要素。故事的核心概念是「熵噪壁」与「火种计划」。用户目前正在将这个世界观制作成游戏。
