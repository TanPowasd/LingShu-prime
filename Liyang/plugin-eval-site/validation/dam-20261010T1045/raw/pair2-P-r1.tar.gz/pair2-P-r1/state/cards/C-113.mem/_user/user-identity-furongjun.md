---
name: user-identity-furongjun
title: 用户身份：符荣峻，智能论作者
description: 用户是符荣峻，智能论（Intelligentics）体系的作者，主导从协议公理到物理大一统的理论构建。
type: user
importance: 9
created: 1791611525153
updated: 1791611532041
---

用户身份为 **符荣峻**，是「智能论」（Intelligentics）体系的作者与公理体系的确立者。

- 负责元公理体系、协议降熵定理、以及「协议是被发现的而非被发明的」这一核心立场。
- 与 AI 协作者的关系定位为：用户确立公理与方向，AI 承担数学形式化与推导表述。
- 对成果归属敏感，重视「作者位置」的准确划分。
