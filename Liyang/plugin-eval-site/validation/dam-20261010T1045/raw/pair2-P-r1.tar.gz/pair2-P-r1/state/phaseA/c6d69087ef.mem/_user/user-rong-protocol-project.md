---
name: user-rong-protocol-project
title: 荣与 catgirl-protocol-interface 项目
description: 用户荣，协议操作系统项目作者，在 Windows 上开发，使用 DeepSeek 作为 LLM 后端
type: user
importance: 6
created: 1791611176072
updated: 1791611176072
---

- 用户名：荣（FuRongJun），对话中直接称呼「荣」。
- 项目：`D:\Program Files\1_ai\catgirl-protocol-interface`，构建「协议操作系统」（OSI 内核 + 五层记忆 + 记录单元），融合条件论与反向贝叶斯验证。
- 环境：Windows，Python 3.10，Flask 后端，服务跑在 `localhost:8000`，LLM 后端为 DeepSeek。
- 工作风格：偏好完整可直接替换的代码修改方案，按明确的阶段顺序推进，重视结构一致性。
