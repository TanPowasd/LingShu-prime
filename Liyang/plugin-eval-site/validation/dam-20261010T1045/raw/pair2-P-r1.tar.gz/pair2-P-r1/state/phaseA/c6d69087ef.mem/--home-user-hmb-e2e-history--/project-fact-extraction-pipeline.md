---
name: project-fact-extraction-pipeline
title: 事实抽取管道流程与推进顺序
description: 流程：条件空间识别→结构化抽取→反向贝叶斯验证→存知识层；须先接文档与LLM再验证
type: project
importance: 7
created: 1791611175979
updated: 1791611175979
---

事实抽取管道（`/fact/extract`）的完整流程：

```
对话输入 → 条件空间识别（输出单元 + LLM）→ 事实结构化抽取 → 反向贝叶斯验证 → 存入知识层
```

产出为附带完整条件空间声明与验证状态（`verified: true` / 待验证）的结构化事实条目。

**已确认的推进顺序**（荣明确要求）：
1. 协议理论版 + 工程版文档接入
2. 条件空间识别接入真实 LLM（DeepSeek）
3. 反向贝叶斯验证完整逻辑

理由：没有文档作为先验基准、没有 LLM 产出完整条件空间声明，验证无法执行。

相关模块：`src/osi/kernel/output.py`（identify_condition_space / extract_fact）、`src/osi/kernel/memory.py`（store_fact）、`src/osi/kernel/verify.py`（verify_fact）、`src/core/instance.py`（路由）。
