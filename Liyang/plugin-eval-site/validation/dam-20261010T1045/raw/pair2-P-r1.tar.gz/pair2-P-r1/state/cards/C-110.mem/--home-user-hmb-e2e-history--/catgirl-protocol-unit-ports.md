---
name: catgirl-protocol-unit-ports
title: 协议实例单元端口与路由映射
description: 代理 8000，记录单元 8001，反思单元 8002；run.py 按单元边界转发
type: project
importance: 6
created: 1791611517830
updated: 1791611517830
---

猫娘计划协议实例的端口与路由：

- 代理服务：8000（统一对外，仅转发不做决策）
- 记录单元：8001
- 反思单元：8002

`run.py` 路由映射：`/memory/*` → 记录单元；`/sleep/batch_decay` → 记录单元；`/sleep/random_associate` → 记录单元（联想功能）；`/sleep/validate` → 验证单元。

**How to apply:** 排查跨单元通信问题时，先确认目标单元端口与 run.py 中的路由映射一致。
