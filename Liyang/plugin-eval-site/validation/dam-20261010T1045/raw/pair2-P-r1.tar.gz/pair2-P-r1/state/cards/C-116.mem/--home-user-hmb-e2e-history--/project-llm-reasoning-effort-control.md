---
name: project-llm-reasoning-effort-control
title: DeepSeek reasoning_effort 参数控制
description: 区分协议思维链（多实例串联，已关闭）与 DeepSeek 模型内部推理深度 reasoning_effort
type: project
importance: 5
created: 1791611543253
updated: 1791611543253
---

两个不同层面的「思维链」需要区分：

1. **协议的思维链**：多实例串联（反思→验证→设计者），已关闭；`/message` 端点是单次 LLM 调用。
2. **DeepSeek 的 reasoning**：模型内部推理深度，通过 `reasoning_effort`（`low`/`medium`/`high`）控制。

已在 `src/osi/drivers/llm.py` 的 `LLMAdapter.chat_completion` 中加入 `reasoning_effort` 支持，当前设为 `"low"`，日志会打印 `🧠 推理深度: low`。

关闭推理深度后思考效果仍好的原因：协议的认知能力来自结构本身（结构约束 / 长期记忆检索 / 条件空间识别 / 反向贝叶斯前置过滤 / 自维持闭环），而非工程上的串联推理。
