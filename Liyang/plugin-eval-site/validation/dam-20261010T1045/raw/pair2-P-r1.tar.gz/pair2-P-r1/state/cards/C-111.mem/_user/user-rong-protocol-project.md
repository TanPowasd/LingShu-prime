---
name: user-rong-protocol-project
title: 用户「荣」：协议设计者
description: 用户名为荣，主导猫娘计划协议的理论与工程实现，关注单元边界与结构澄清
type: user
importance: 8
created: 1791611523541
updated: 1791611526161
---

用户名为**荣**（记忆 metadata 中 user 字段为「荣」）。

角色：猫娘计划（catgirl-protocol-interface）的设计者/主导者，同时参与协议理论层与工程实现层。

偏好：
- 重视结构层面的澄清，倾向从工程实践中反推理论修正
- 会主动质疑既有单元划分，要求把理论澄清提交给验证单元并让反思单元反思
- 沟通风格简短直接（如「已经修改了」「开始」「instance.py」）
- 期望助理输出可直接替换的完整文件（如「直接输出完整的 instance.py」）

**How to apply:** 讨论时区分「理论职能划分」与「工程实现」，不要默认单元必须物理分离。
