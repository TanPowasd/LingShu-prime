---
name: feedback-unify-data-structures-not-patch
title: 同一问题重复三次须进入反思流程
description: 荣要求：重复报错三次时应上升到结构层反思，统一数据结构而非逐处打补丁
type: feedback
importance: 8
created: 1791611176015
updated: 1791611176015
---

荣在同一个 `AttributeError: 'str' object has no attribute 'get'` 连续出现三次后明确要求「进入反思流程」。

**Why:** 在补丁层面反复处理同一类型错误，说明问题根源在数据结构本身，而非某一行代码。

**How to apply:** 当同一错误重复出现 ≥3 次时，停止局部修补，上升到结构层分析根因并统一数据结构。本例中 `MemorySystem._layers` 的条目类型不统一（来源包括 `record_instance._memory` 的字典、`MemorySystem.store()` 的 MemoryEntry 对象），正确做法是统一为 `MemoryEntry`，而不是在每个访问点做类型防御。
