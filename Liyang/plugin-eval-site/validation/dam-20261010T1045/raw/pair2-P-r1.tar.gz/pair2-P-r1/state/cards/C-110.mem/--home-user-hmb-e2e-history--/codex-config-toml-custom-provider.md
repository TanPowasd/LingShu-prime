---
name: codex-config-toml-custom-provider
title: Codex 配置文件指向猫娘自定义 provider
description: ~/.codex/config.toml 配置 custom provider 指向 localhost:8000，需含 name
  字段且 model_provider 在顶层
type: reference
importance: 7
created: 1791611523815
updated: 1791611523815
---

## Codex 配置文件位置（Windows）

`C:\Users\FuRongJun\.codex\config.toml`（即 `~/.codex/config.toml`）

## 可用配置

```toml
model = "protocol-instance"
model_provider = "custom"

[model_providers.custom]
name = "custom"          # 必须！缺失会报 "provider name must not be empty"
base_url = "http://localhost:8000/v1"
api_key = "any-key"      # Codex 要求非空，猫娘不校验
model = "protocol-instance"
```

## 已知约束

- `--approve-for-me` 是顶级选项，会自动启用沙箱，**不能与 `--sandbox` 同时使用**
- Codex 默认沙箱为 `read-only`；需要写权限时用 `--dangerously-bypass-approvals-and-sandbox` 或配置 `sandbox: workspace-write`
- Codex 调用的是 **`/v1/responses`** 端点（非 `/v1/chat/completions`），猫娘需适配
- `model = "protocol-instance"` 会触发 `Model metadata not found` 警告，回退到默认元数据
- Windows 命令行中中文提示词需用引号包裹，或改用 PowerShell / Python 直接调用

**Why:** 配置格式踩过坑（缺 name 字段、误加 --sandbox），记录下来避免重复调试。
