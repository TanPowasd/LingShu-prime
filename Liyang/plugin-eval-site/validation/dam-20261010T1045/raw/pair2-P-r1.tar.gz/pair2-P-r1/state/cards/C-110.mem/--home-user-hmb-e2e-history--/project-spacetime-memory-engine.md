---
name: project-spacetime-memory-engine
title: 项目：时空记忆引擎（spacetime-memory-engine）
description: Flask 引擎位于 D:\Program Files\2_ai\spacetime-memory-engine，端口 8899，集成
  CodeGraph 代码域探针。
type: project
importance: 7
created: 1791611519375
updated: 1791611519375
---

**时空记忆引擎**项目路径：`D:\Program Files\2_ai\spacetime-memory-engine`（Windows，Python 3.10 venv）。

- 主文件：`spacetime-memory-engine.py`，Flask 应用，`WebInterface._setup_routes` 定义路由；服务监听 `http://localhost:8899`
- 核心类：`SpacetimeMemoryEngine`、`CodeGraphAdapter`
- 集成 **CodeGraph**（npm 包 `@colbymchenry/codegraph`）作为代码域探针，数据库位于 `.codegraph/codegraph.db`
- 同步端点：`POST /api/codegraph/sync`

已知环境坑（Windows）：
- 全局 npm 包路径（`C:\Users\FuRongJun\AppData\Roaming\npm`）可能不在 `subprocess` 的 PATH 中，`_check_availability` 需用 `shutil.which` 或完整路径探测
- 系统未安装 `sqlite3` CLI，查库需用 Python 的 `sqlite3` 模块

CodeGraph 数据库实际结构（与适配器早期假设不符）：
- 表名是 `nodes` 而非 `symbols`；核心表：`nodes`、`edges`、`files`、`unresolved_refs`、`schema_versions`、`project_metadata`
- `nodes` 列名是 `start_line` / `end_line`，不是 `line_start` / `line_end`
- 需先运行 `codegraph index` 才会生成表结构（示例：2 文件 → 117 nodes / 191 edges）
