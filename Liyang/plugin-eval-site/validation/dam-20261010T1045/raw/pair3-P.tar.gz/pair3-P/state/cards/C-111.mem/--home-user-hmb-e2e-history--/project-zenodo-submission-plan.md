---
name: project-zenodo-submission-plan
title: 发布计划：Zenodo 优先，arXiv 待时机
description: 先提交 Zenodo 锁定时间戳（无需背书），arXiv 需 endorsement 且要求 LaTeX 源文件
type: project
importance: 7
created: 1791609847904
updated: 1791609847904
---

用户的发布路径决策：

- **首选 Zenodo**：因为用户是独立研究者、缺乏 arXiv 背书（endorsement）。Zenodo 提交前提：注册账号（可用 GitHub/ORCID 登录）、注册 ORCID iD（强烈建议）、选择 CC BY 4.0 许可证、可选加入社区。
- **arXiv 暂缓**：arXiv 要求首次提交者获得背书（2026年1月21日起新规：需机构邮箱 + 已是 arXiv 作者，或找 gr-qc 领域资深作者个人背书）。目标分类为 **gr-qc**（广义相对论与量子宇宙学）。
- **arXiv 材料要求**：不能只提交 PDF；若用 LaTeX 生成，必须提交可编译的 `.tex` 源文件（含 `.bbl` 或直接使用 thebibliography 环境）。
- 用户决定：先把理论继续深化，不急于发邮件联系研究者；静待时机。
- 外联策略（KIMI 建议，已采纳）：不请求“评审/验证”，而是邀请研究者评估“由元协议约束的理论构建方式”能否为其领域提供新组织视角。
