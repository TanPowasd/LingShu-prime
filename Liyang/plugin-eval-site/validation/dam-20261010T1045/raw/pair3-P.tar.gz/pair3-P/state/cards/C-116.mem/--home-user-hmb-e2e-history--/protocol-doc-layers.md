---
name: protocol-doc-layers
title: 协议文档未写入 knowledge 层（待修复）
description: 协议理论/工程/特化价值观只进了 anchor 层，knowledge 层缺失，导致猫娘检索不到协议内容
type: project
importance: 7
created: 1791609863411
updated: 1791609874779
---

已确认的缺陷：协议理论版（v2.9，约 50390 字符）成功加载进 `anchor` 层，但 `knowledge` 层中**没有** `protocol_theory_full`、`protocol_engineering_full`、`specialized_values_full` 三条记录——knowledge 层里全是对话历史和睡眠固化的事实抽取结果（且大量 `condition_space: 条件空间识别失败`）。

后果：猫娘被问「你的特化价值观是什么」时凭空生成（「一直陪着你、让你开心、守住协议、拿小鱼干」），未引用协议中定义的 5 条特化价值观（共生优先 / 结构诚实 / 共情不盲从 / 记忆尊严 / 面向弱者的偏向）。

**How to apply:** 检查 `run.py` 的 `_initialize_instances()` 中依赖 `MemorySystem.get_protocol_context()` 的写入逻辑，确认协议内容确实落到 knowledge 层（最高权重），而非仅 anchor 层。
