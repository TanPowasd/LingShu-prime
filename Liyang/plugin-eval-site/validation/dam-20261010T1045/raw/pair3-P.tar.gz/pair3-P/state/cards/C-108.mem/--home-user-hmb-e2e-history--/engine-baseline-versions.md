---
name: engine-baseline-versions
title: 引擎与协议基线版本
description: 协议基线智能论v3.2；引擎基线时空记忆图v1.11 + 自我认知循环v1.12；AEIS库版本迭代中
type: project
importance: 7
created: 1791609840579
updated: 1791609840579
---

项目当前的版本基线：

- **协议基线**：《智能论》v3.2（结构收敛版），含 3.3 节验证单元权力制衡、3.3.1 条件空间复核、附录 H 复核范式。
- **引擎基线**：时空记忆图 v1.11 + 自我认知循环 v1.12（`spacetime-memory-engine`）。
- **工程库**：灵枢 AEIS 库（`aeis/`），已发布 v0.3.0（2026-08-13 提交 `feat(aeis): 灵枢 AEIS 工程实现 v0.3.0 开源发布`）。
- 相关参考：`ARCH-SIX-INSTANCE-20260808-FINAL`、`ARCH-FIVE-BRIDGES` 映射参考。
- 关键代码组件：`cognition_cycle`（价值迭代候选）、`STNode.condition_space`（条件空间标签）、`value_evolution` / CHANGELOG（可追溯变更）。
