---
name: project-spacetime-memory-engine
title: 项目：时空记忆引擎（spacetime-memory-engine）
description: 位于 D:\Program Files\2_ai\spacetime-memory-engine 的 Flask 项目，集成 CodeGraph 代码域探针。
type: project
importance: 7
created: 1791609865681
updated: 1791609865681
---

**时空记忆引擎** 项目路径：`D:\Program Files\2_ai\spacetime-memory-engine`，主文件 `spacetime-memory-engine.py`。

- Web 服务：Flask，默认端口 `8899`。
- 关键类：`SpacetimeMemoryEngine`、`WebInterface`（`_setup_routes`）、`CodeGraphAdapter`（`_check_availability`、`sync_to_spacetime`）。
- 端点：`/api/codegraph/sync`（POST）用于将 CodeGraph 索引同步进时空图。
- 运行环境：Windows，Python 3.10，venv。
