---
name: xiaoying-socrates-architecture
title: 小萤/苏格拉底系统架构要点
description: FastAPI+DeepSeek-R1；苏格拉底与小萤需独立记忆系统隔离，共享全局知识但角色目标分离
type: project
importance: 7
created: 1791609512516
updated: 1791609512516
---

**技术栈**：FastAPI + DeepSeek-R1 (deepseek-reasoner) + OpenAI SDK，前端为HTML页面。

**核心架构决策**：
- 苏格拉底和小萤必须有**独立的对话历史存储目录**（conversations_socrates / conversations_xiaoying），仅共享全局知识库（knowledge_states）。
- 原因：共享记忆上下文导致苏格拉底无法可靠区分「用户提问」还是「小萤提问」，从而风格漂移（变得过于柔软/孩子气）。
- 仅靠System Prompt强化角色边界不足以解决此问题，必须做信息隔离。

**苏格拉底核心策略**（已内化）：先提问后解释；共情后降低难度但不放弃引导；用生活场景（零花钱、篮球赛、晒谷场）做认知脚手架；面对非教学类提问不拒绝但引向认知探索。

**部署方式**：使用SakuraFrp内网穿透（本地端口8000），后续计划添加PWA支持。
