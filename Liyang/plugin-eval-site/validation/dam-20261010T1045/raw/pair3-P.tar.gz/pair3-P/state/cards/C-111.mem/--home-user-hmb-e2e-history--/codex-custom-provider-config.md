---
name: codex-custom-provider-config
title: Codex 自定义 LLM 提供者配置要点
description: config.toml 需 name 字段；Codex 调用 /v1/responses 而非 /v1/chat/completions，需适配器
type: reference
importance: 7
created: 1791609860389
updated: 1791609860389
---

Codex CLI v0.147.0 配置文件位于 `C:\Users\<用户名>\.codex\config.toml`（Windows）。

可用配置：
```toml
model = "protocol-instance"
model_provider = "custom"

[model_providers.custom]
name = "custom"
base_url = "http://localhost:8000/v1"
api_key = "any-key"
model = "protocol-instance"
```

踩坑记录：
- `[model_providers.custom]` 缺少 `name` 字段会报 `provider name must not be empty`。
- Codex 请求的是 **`/v1/responses`** 端点（不是 `/v1/chat/completions`），猫娘需实现该适配器，否则 404。
- 猫娘返回纯文本会导致 `stream disconnected before completion: stream closed before response.completed`——Codex 期望流式响应格式。
- Windows 下中文提示词需用引号包裹，或用 `--` 分隔选项与提示词。
- 顶层选项 `--approve-for-me` 会自动启用沙箱，不能与 `--sandbox` 同用。
