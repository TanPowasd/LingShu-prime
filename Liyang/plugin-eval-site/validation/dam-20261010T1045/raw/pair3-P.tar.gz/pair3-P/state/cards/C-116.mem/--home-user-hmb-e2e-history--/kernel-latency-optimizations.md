---
name: kernel-latency-optimizations
title: 内核响应延迟优化：关闭 DeepSeek 思维链 + 异步保存
description: reasoning_effort=low 关闭 DeepSeek 推理深度；对话历史保存改为异步不阻塞响应
type: project
importance: 6
created: 1791609874718
updated: 1791609874718
---

针对内核响应慢（~10.8s）的两项已实施优化：

1. **关闭 DeepSeek 模型思维链**：在 `src/osi/drivers/llm.py` 的 `LLMAdapter` 中设置 `reasoning_effort="low"`（DeepSeek 特有参数，控制模型内部推理深度，与协议的「实例串联思维链」是两回事——后者早已关闭）。日志会打印 `🧠 推理深度: low`。
2. **异步保存对话历史**：`/message` 端点中对话历史的保存改为异步提交，不阻塞响应返回（日志 `💾 对话历史保存已提交（异步）`）。

**Why:** 用户感知的延迟主要来自 LLM 推理与同步保存；关闭推理深度后思考效果依然良好，因为协议认知能力来自结构约束（价值观 + 长期记忆检索 + 条件空间识别 + 前置验证），而非模型内部思维链。
