---
name: fact-extraction-pipeline-design
title: 事实抽取管道设计
description: 对话→条件空间识别→事实结构化抽取→反向贝叶斯验证→存入知识层的完整流程
type: project
importance: 7
created: 1791609855102
updated: 1791609855102
---

事实抽取管道的完整流程：

```
输入文本 → 条件空间识别（输出单元 + LLM）→ 反向贝叶斯验证 → 存入知识层
```

验证逻辑：第零定律一致性检查 + 锚点层/结构层历史参照 + 知识层已有结构对齐。通过则标记 `verified: true`；未通过则标记「待验证」但保留存储。

涉及端点：`/fact/extract`（事实抽取）、`/fact/condition/identify`（条件空间识别）。

推进顺序（用户明确指定）：**协议理论版+工程版文档接入 → 接入 LLM → 完善反向贝叶斯验证**。
