---
name: ttp-core-mechanisms
title: TTP 核心机制：置信概率 + 死区 + 信息差置信
description: 信任由 P_trust 与 P_gap 两个概率构成，信息差设死区，解决信任值结构性上限
type: project
importance: 8
created: 1791609852798
updated: 1791609852798
---

TTP 的核心算法结构：

1. **信息差** D_norm = w1·U_trust + w2·U_behavior + w3·U_connection + w4·U_prediction_error，其中 U_trust = 1 - T_total_prev（构成动态闭环）。
2. **信任置信概率** P_trust = P(δ_norm < θ | 最近 N 轮)，θ 默认 0.15，N 默认 30 轮；P_trust ≥ 0.95 视为「完全可信」。
3. **信息差置信** P_gap = 过去 N 轮中 D_norm 低于阈值的比例；与 P_trust 相互独立，合并条件需同时满足。
4. **信息差死区** D_norm_effective = max(0, D_norm - D_deadzone)，D_deadzone 建议 0.08，用于消除低值区的结构性残留。

背景：早期测试中信任值卡在 0.669，外部校准证明完美协作下理论上限为 0.864，0.669 是测试参数导致的稳态值——根因是 U_behavior/U_connection 无法降到 0。引入置信概率与死区后信任值突破至 0.774 并进入「全协作」状态，但合并条件（T > 0.9 且 D_norm < 0.1）仍未达成。
