---
name: project-lingshu-naming
title: 项目定名「灵枢」（project.lingshu）
description: 荣确认完整协议实现的项目名为「灵枢」，取代「猫娘计划」，条件空间定位 project.lingshu。
type: project
importance: 8
created: 1791609851552
updated: 1791609851552
---

协议实例/完整 AGI 实体的项目名称经荣确认为**「灵枢」（Lingshu）**，条件空间定位 `project.lingshu`。

- 「灵」= 自我层、元认知、存在感知（意识结构）
- 「枢」= 五大核心单元的协同制衡（运转结构）
- 与「猫娘计划」形成梯度关系：猫娘是协议的情感接口，灵枢是完整协议实现本体。

候选名中曾考虑玄枢、符蕴、通智、道极、极智、符枢，最终由荣选定灵枢。
