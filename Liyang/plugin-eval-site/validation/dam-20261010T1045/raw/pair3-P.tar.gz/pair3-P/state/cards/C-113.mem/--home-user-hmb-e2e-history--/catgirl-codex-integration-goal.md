---
name: catgirl-codex-integration-goal
title: 猫娘接入 Codex 的演进目标与路径
description: 短期让猫娘调用 Codex 的网页搜索与代码修改能力跑通闭环，长期用原生模块逐步替代 Codex
type: project
importance: 9
created: 1791609864663
updated: 1791609864663
---

项目 catgirl-protocol-interface 的既定演进路径：

1. 阶段1（当前）：猫娘 → Codex（网页搜索 + 代码修改），把“意图→搜索→修改→验证”闭环跑通
2. 阶段2：猫娘 → Codex（仅代码修改）+ 原生 SearchExecutor（搜索）
3. 阶段3：猫娘 → 原生操作引擎（代码修改）+ 原生 SearchExecutor（搜索）
4. 阶段4：完全移除 Codex 依赖

**Why:** 猫娘自身的自我学习与代码修改能力尚未完善，先用成熟的 Codex 赋能，再逐步替换。
**How to apply:** 讨论架构时不要试图把 Codex 改造成猫娘的一部分，也不要让 Codex 反向调用猫娘替代 GPT——方向是猫娘调用 Codex。
