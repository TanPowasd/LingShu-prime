---
name: catgirl-protocol-project-overview
title: 猫娘计划项目概况
description: 多单元 AGI 协议项目，含记录/反思/验证等单元，通过代理服务统一路由
type: project
importance: 8
created: 1791609514643
updated: 1791609514643
---

项目路径：`D:\Program Files\1_ai\catgirl-protocol-interface`。

架构：多单元（原称「五大核心单元」）AGI 协议实现，各单元以独立进程运行：
- 记录单元（record，端口 8001）：存储、检索、衰减、归档、即时联想
- 反思单元（reflection，端口 8002）：高阶整合、模式识别
- 验证单元：结构化筛选
- 代理服务 `run.py`（端口 8000）：统一对外，按单元边界规范转发请求

核心文件：`instance.py`（各单元端点实现）、`run.py`（路由代理）。

记忆分层：anchor / context（情境层）/ knowledge（知识层）/ self / structure。

技术栈：Flask + ChromaDB + sentence-transformers（HF 镜像 hf-mirror.com）。
