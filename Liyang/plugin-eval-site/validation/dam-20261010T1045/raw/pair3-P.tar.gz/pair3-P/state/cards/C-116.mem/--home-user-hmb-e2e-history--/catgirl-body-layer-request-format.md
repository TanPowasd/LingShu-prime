---
name: catgirl-body-layer-request-format
title: 猫娘身体层请求特征与超时配置
description: 身体层走 OpenAI 兼容接口、10 秒超时、stream:true、max_completion_tokens:1 探活
type: project
importance: 6
created: 1791609874662
updated: 1791609874662
---

猫娘身体层（外部客户端）的实际请求特征（来自日志）：

- 接入地址 `http://localhost:8000/v1`，模型 ID `protocol-instance`，走 `/v1/chat/completions` 代理到 `/message`。
- 客户端为 AsyncOpenAI/Python 2.8.1（X-Stainless-* 头，Read-Timeout: 10.0）。
- **请求超时 10 秒**，而内核一次完整对话约 10.8 秒（反向贝叶斯 ~1s + 记忆检索 ~0.5s + LLM 推理 ~3-5s + 保存 ~2s），刚好卡边界导致超时。
- 连通性测试会发 `max_completion_tokens: 1` 的探活请求。
- 正式对话使用 `stream: true`，且 user 消息会包一层「======以下是环境提示======」环境提示文本。

**How to apply:** 排查身体层问题先看 `/v1/chat/completions` 的完整请求日志（Headers + Body）；超时优先把身体层超时调到 30-60 秒，或继续压缩内核关键路径耗时。
