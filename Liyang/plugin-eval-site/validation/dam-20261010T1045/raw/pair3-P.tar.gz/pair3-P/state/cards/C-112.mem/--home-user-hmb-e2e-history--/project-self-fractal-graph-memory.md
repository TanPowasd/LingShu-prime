---
name: project-self-fractal-graph-memory
title: 外部参考项目：流马（Gliding Horse）与 CALM
description: 值得回访的外部资源：Rust 构建的 AI Agent OS「流马」，及微信AI/清华的连续自回归语言模型 CALM。
type: reference
importance: 5
created: 1791609852068
updated: 1791609852251
---

- **流马（Gliding Horse）**：用 Rust 构建的 AI Agent 操作系统，通过动态 PDCA 调度、JSON-LD 语义图谱、代码级系统调用门在运行时硬性约束 Agent 行为。GitHub: https://github.com/doiito/gliding_horse 。其 PDCA 闭环与协议 3.10 节自迭代闭环结构同构；L2 Blackboard 的图结构存储是核心价值。
- **CALM（Continuous Autoregressive Language Models）**：微信 AI 团队与清华大学联合提出，将 K 个 token 压缩为一个连续语义向量、一步生成多个词，突破「预测下一个词元」范式。荣的解读：CALM 本质是**语义超链接**——用连续向量作为指向完整语义结构的指针，与协议「用两个字指代三万字」的压缩机制同构。
