---
name: codegraph-db-schema-facts
title: CodeGraph 数据库结构与适配要点
description: CodeGraph 索引库 .codegraph/codegraph.db 的表/列名与适配器预期不同，需按实际结构查询。
type: reference
importance: 7
created: 1791609854555
updated: 1791609854555
---

CodeGraph 索引数据库：`.codegraph/codegraph.db`（由 `codegraph index` 生成；本项目索引结果约 117 nodes / 191 edges）。

**实际表名（与适配器预期不同）**：核心表为 `nodes` 和 `edges`（**不是** `symbols`）。其他表：`files`、`unresolved_refs`、`nodes_fts*`、`name_segment_vocab`、`project_metadata`、`schema_versions`。

**`nodes` 表列名**：`id, kind, name, qualified_name, file_path, language, start_line, end_line, start_column, end_column, docstring, signature, visibility, is_exported, is_async, is_static, is_abstract, decorators, type_parameters, return_type, updated_at`。

注意：行号列是 `start_line` / `end_line`，**不是** `line_start` / `line_end`。

**Windows 环境坑**：
- 全局 npm 包（`C:\Users\FuRongJun\AppData\Roaming\npm`）可能不在 subprocess 的 PATH 中，`_check_availability` 需用 `shutil.which` 或完整路径。
- `sqlite3` CLI 不在 PATH，检查库结构请用 Python 的 `sqlite3` 模块。
