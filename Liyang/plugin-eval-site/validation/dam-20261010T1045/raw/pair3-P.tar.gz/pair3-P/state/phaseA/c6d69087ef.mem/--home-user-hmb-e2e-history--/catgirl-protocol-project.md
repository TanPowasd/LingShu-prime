---
name: catgirl-protocol-project
title: catgirl-protocol-interface 项目
description: 协议操作系统项目，用户荣主导，Python/Flask，路径 D:\Program Files\1_ai\catgirl-protocol-interface
type: project
importance: 6
created: 1791609507497
updated: 1791609507497
---

项目路径：`D:\Program Files\1_ai\catgirl-protocol-interface`，Python 3.10 + Flask，运行入口 `src/run.py`，服务端口 8000。

核心模块：`src/osi/kernel/`（memory.py 记忆系统、output.py 输出单元、verify.py 验证单元）、`src/core/instance.py`（路由与实例）、`src/osi/__init__.py`。

用户称呼为「荣」。LLM 使用 DeepSeek（通过 LLMAdapter）。

已完成里程碑：记忆持久化、重要性评估、联想功能迁移与验证（跨层相似度 0.743, valid:true）、OSI 内核集成、协议文档加载。

注意：Flask 在 IDE 中报「无法解析导入」但运行时可用，属环境不一致，非代码问题。
