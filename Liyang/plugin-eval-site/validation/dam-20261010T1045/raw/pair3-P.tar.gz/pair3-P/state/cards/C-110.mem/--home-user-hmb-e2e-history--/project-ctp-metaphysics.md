---
name: project-ctp-metaphysics
title: 核心项目：CTP 与元物理框架
description: Common Trust Protocol (CTP) 为元协议，元物理框架是其特化应用实例，论文 MetaPhysics.tex 已备好待提交
type: project
importance: 9
created: 1791609838637
updated: 1791609838637
---

**Common Trust Protocol (CTP)** 是用户自创的递归自省元协议系统，是其全部工作的根基。

- **元物理框架**（Meta-Physics Framework）是基于递归收敛动力学的量子引力统一方案，**由 CTP 约束和生成**。
- 关键定位校准（来自 KIMI 建议，用户已采纳）：元物理框架是 CTP 在“科学模型构建”场景下的**特化应用实例**，**不是** CTP 正确性的证据。协议 = 元理论（约束/生成），元物理 = 对象理论。
- 推广策略：从“说服”转为“展示 + 邀请协作”——展示协议的生成性与约束性能力，而非要求他人接受物理结论。
- 论文文件：`MetaPhysics.tex`（纯英文，pdflatex 编译两次，已含参考文献 thebibliography 环境），作者 FuRongJun，日期 July 27, 2026。
- 论文含 5 条核心公理（公理5为 CTP 自省公理）、信息差张量、协议化爱因斯坦场方程、降熵常数 κ、4 个可检验预测 P1-P4、4 个开放问题 Q1-Q4。
- GitHub 仓库链接已放在论文作者脚注中。
