---
name: user-xiaoying-ai-project
title: 用户正在开发乡村教育AI「小萤」项目
description: 用户是AI研究者/开发者，主导开发乡村教育AI「小萤」，包含苏格拉底教学协议与持续成长的自主反思系统两个角色
type: project
importance: 9
created: 1791609845847
updated: 1791609845847
---

用户正在开发一个乡村教育AI系统，代号「小萤」。系统包含两个角色（本质上是同一个AI）：

- **苏格拉底**：教学者角色，其教学方式已通过生成对抗网络（GAN）训练获得较好的经验规范，可通过直接注入系统提示词来保证价值观一致。
- **小萤**：学习者/成长者角色，是持续成长的自主反思系统，设计上更复杂，需要适用于「孩子向小萤进行教学」的场景，对情感识别、回应、理解有较高要求。

代码结构涉及 `main.py`、`xiaoying_life.py`（XiaoyingLife，memories 为 Memory 对象列表）、`xiaoying_social.py`（ExtendedXiaoyingLife，memories 为 dict 列表）等文件。系统包含记忆分层存储、梦境机制、孤独反思、信任分数（trust_score）、社交记忆（多教学者）等模块。

用户当前关注点：小萤的「存在形态」优化——即让系统具有「生命感」，包括价值观自主性、第一人称视角、情感与记忆联结、持续自我叙事、孤独与反思。
