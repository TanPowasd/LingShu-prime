---
name: catgirl-protocol-project
title: 协议端点约定与角色检查
description: 各单元端点通过 role 检查隔离；/memory/all 提供全量只读访问
type: project
importance: 6
created: 1791609839015
updated: 1791609841835
---

端点设计约定：

- 每个端点通过 `if self.config.role != "<role>": return 403` 做角色隔离。
- `/memory/search`：语义检索，**查询为空时不返回任何条目**；带 `threshold` 过滤，跨层相似度低时知识层会被筛掉。
- `/memory/all?layer=<层>`：新增端点，返回指定层级**全部**记忆数据，供其他单元只读访问（仅 record 单元提供）。返回结构形如 `{"context": [...]}`，消费方应使用 `data.get("context", [])` 提取。
- `/memory/store`：写入记忆，返回 `{count, entry, layer, status}`。
- `/memory/summary`：返回各层计数与角色信息。

调试常用：`curl -X POST http://localhost:8000/memory/store`、`curl http://localhost:8001/memory/all?layer=context`、`curl -X POST http://localhost:8000/sleep/random_associate`。
