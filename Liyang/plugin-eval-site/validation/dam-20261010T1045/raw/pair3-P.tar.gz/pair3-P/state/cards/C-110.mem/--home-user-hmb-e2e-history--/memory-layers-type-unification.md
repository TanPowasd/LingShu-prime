---
name: memory-layers-type-unification
title: 记忆系统 _layers 数据结构统一
description: MemorySystem._layers 条目类型混用导致反复报错，须统一为 MemoryEntry
type: feedback
importance: 7
created: 1791609840996
updated: 1791609840996
---

`MemorySystem._layers` 中的条目类型不统一：来自 `record_instance._memory`（磁盘加载）的是 dict，来自 `store()` 的是 `MemoryEntry` 对象，且 dict 的 content 可能是 str 或 dict。这导致 `load_protocol_document` 等访问 `entry.content` / `entry.get(...)` 时反复抛 AttributeError（同一问题出现三次）。

**Why:** 在每处访问做类型防御只是补丁，根源是数据结构本身混乱，会在每个新访问点复现。

**How to apply:** 统一 `_layers` 数据结构为 `MemoryEntry`（在数据入口处归一化），而不是在每次访问时做 isinstance 分支。遇到重复出现的类型错误时，上升到结构层修复而非继续打补丁。
