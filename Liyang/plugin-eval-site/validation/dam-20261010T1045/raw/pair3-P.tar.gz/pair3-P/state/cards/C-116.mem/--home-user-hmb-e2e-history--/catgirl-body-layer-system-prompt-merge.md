---
name: catgirl-body-layer-system-prompt-merge
title: 猫娘身体层 System Prompt 与协议约束合并方案
description: 身体层外部 System Prompt 不再覆盖协议约束，改为合并；反向贝叶斯验证合并后的完整请求
type: project
importance: 7
created: 1791609874613
updated: 1791609874613
---

猫娘身体层（外部客户端，如测试页面/OpenAI 兼容调用方，User-Agent: AsyncOpenAI/Python 2.8.1）会在请求中自带 `role: system` 消息（如「你是一个角色扮演大师…YUI」），此前会覆盖内核的协议系统提示词，导致特化价值观被稀释、猫娘凭空生成回复而不引用协议记忆。

**已确认的修复方向（在 `run.py` 的 `openai_compatible()` 端点实现）**：
- 身体层 System Prompt 与协议约束**合并**，协议价值观作为上层约束，外部指令在协议框架内生效。
- 反向贝叶斯验证改为验证**整个请求**（含合并后的系统提示词），而非仅用户消息。

**Why:** 协议约束必须是最高优先级，外部角色扮演指令不得绕过或覆盖它。
**How to apply:** 修改 `/v1/chat/completions` 端点：先取出身体层 system 消息，与 `_get_protocol_system_prompt()` 合并（协议在前/为上层），再把合并结果送入反向贝叶斯验证。
