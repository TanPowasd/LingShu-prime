---
name: source-aware-prompt-injection
title: 按调用来源注入特化上下文的方案
description: 同一入口识别调用来源（人类 vs Codex），动态注入不同系统提示词，而非写独立适配器
type: feedback
importance: 7
created: 1791609865144
updated: 1791609865144
---

荣提出的工程方案：不单独为 Codex 写适配器，而是在现有请求入口（`/message`、`/v1/chat/completions`）识别调用来源，据此注入不同的系统提示词。

- 人类调用 → 温暖自然的对话风格
- Codex 调用 → 输出可解析的 JSON 命令格式

**Why:** 复用现有处理逻辑，保持接口一致性，比多写一个适配器更干净。
**How to apply:** 通过请求头或请求体中的标识区分调用者；识别到 Codex 时注入“指令生成器”行为约束。该方案已由荣实现并写入代码。
