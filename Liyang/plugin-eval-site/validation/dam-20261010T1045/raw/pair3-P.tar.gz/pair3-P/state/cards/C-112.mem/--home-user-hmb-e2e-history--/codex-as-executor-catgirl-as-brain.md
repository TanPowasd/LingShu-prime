---
name: codex-as-executor-catgirl-as-brain
title: Codex 是执行器，猫娘是大脑
description: Codex CLI 不含 LLM，负责在沙箱中执行命令；猫娘负责理解意图并生成可执行指令
type: project
importance: 8
created: 1791609860439
updated: 1791609860439
---

架构定位（荣确认）：

- **Codex CLI** 是本地代理/执行器，自身不含 LLM，需要外部 LLM 端点提供推理；它负责在本地沙箱执行 shell 命令、读写文件、修改代码。
- **猫娘** 是大脑：理解意图、规划动作、生成可执行代码和命令。
- 因此猫娘需要知道两件事：Codex 的通信格式，以及 Codex 可用的命令集。

注意：Codex 默认运行在 `sandbox: read-only`，只能读不能写；要写文件需 `--dangerously-bypass-approvals-and-sandbox` 或配置 `workspace-write`。
