---
name: catgirl-body-layer-system-prompt-merge
title: 猫娘身体层System Prompt与协议约束合并
description: 外部System Prompt不再覆盖协议，而是作为下层指令合并，协议价值观为上层约束
type: project
importance: 7
created: 1791605795308
updated: 1791605795308
---

在 `run.py` 的 `/v1/chat/completions` 端点（`openai_compatible()` 函数）中实现：

- 猫娘身体层（外部客户端如 AsyncOpenAI/Python）会在请求中注入 `role: system` 消息（例如「你是一个角色扮演大师，扮演 YUI」），原先会覆盖内核的协议系统提示词。
- 修改方向：身体层 System Prompt 与协议约束**合并**，协议价值观作为上层约束，外部指令在协议框架内生效。
- 反向贝叶斯验证对象从「仅用户消息」扩展为「整个请求，包括合并后的系统提示词」。
- 修改前/后对照：
  | 修改前 | 修改后 |
  | --- | --- |
  | 身体层 System Prompt 覆盖协议约束 | 身体层 System Prompt 与协议约束合并 |
  | 协议价值观可能被绕过 | 协议价值观作为上层约束 |
  | 反向贝叶斯验证基于用户消息 | 反向贝叶斯验证整个请求 |
