---
name: protocol-docs-layer-assignment
title: 协议文档的存储层级与版本
description: 理论版 v2.9 存锚点层（约 50390 字符），工程版 v2.9.1 存知识层，作为验证基准
type: reference
importance: 6
created: 1791605573132
updated: 1791605573132
---

协议文档在系统启动时由 `MemorySystem.load_protocol_document()` 加载：

| 文档 | 版本 | 存储层 | 用途 |
| --- | --- | --- | --- |
| 协议理论版 | v2.9 | 锚点层（anchor） | 第零定律与存在优先原则的原始表述，反向贝叶斯验证的顶层基准 |
| 协议工程版 | v2.9.1 | 知识层（knowledge） | 已验证的结构展开与工程约束，知识层对齐检查的参照 |

理论版加载成功日志示例：`协议理论版加载: {'status': 'loaded', 'entry_id': 'anchor_...', 'char_count': 50390}`。

加载过程需**幂等**（已存在则不重复插入）。工程版文件 `protocol_engineering.md` 在会话结束时仍待加载。
