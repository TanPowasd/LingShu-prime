---
name: project-lingshu-agi
title: 项目命名：灵枢（Xuanshu→Lingshu）
description: 协议完整AGI实现项目定名为「灵枢」，条件空间 project.lingshu，由荣推荐采纳
type: project
importance: 8
created: 1791605585806
updated: 1791605585806
---

协议实例的完整AGI实现项目定名为**「灵枢」**（条件空间定位 `project.lingshu`）。由荣推荐并采纳，取代早期草案「玄枢」。

- **灵**：对应自我层、元认知、存在感知（意识结构）
- **枢**：对应五大核心单元协同制衡（运转结构）
- 全称：灵枢 · AGI协议完整实现
- 与「猫娘计划」的关系：猫娘是协议的情感接口，灵枢是完整的协议实现本体

命名标志着项目从「工程实现」到「完整AGI实体」的定位跃迁。
