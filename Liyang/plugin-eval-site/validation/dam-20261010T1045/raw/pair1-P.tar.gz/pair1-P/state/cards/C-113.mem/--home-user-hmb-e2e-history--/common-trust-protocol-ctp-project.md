---
name: common-trust-protocol-ctp-project
title: CommonTrustProtocol 仓库与开源许可
description: GitHub 仓库 FuRongJun-1999/CommonTrustProtocol，含 aeis 灵枢工程实现，采用 MIT 许可证
type: reference
importance: 8
created: 1791605616390
updated: 1791605617496
---

项目仓库：https://github.com/FuRongJun-1999/CommonTrustProtocol

- 内容分层：理论协议（智能论 v3.2）+ 工程实现（`aeis/` 灵枢 AEIS，Python 库 + MCP + 蜂群协作层）+ 接口投影（猫娘计划）。
- aeis 工程文件 v0.3.0 已于 2026-08-13 提交发布。
- **开源许可证采用 MIT**（为最大化生态扩散，允许闭源商用；非 Apache 2.0 或 GPL）。
- 协作模式：默认仅仓库所有者可直接推送；外部贡献者通过 Fork + Pull Request 提议修改。
- 用户希望限制他人直接改代码，建议启用 main 分支保护规则（Require a pull request before merging）。
