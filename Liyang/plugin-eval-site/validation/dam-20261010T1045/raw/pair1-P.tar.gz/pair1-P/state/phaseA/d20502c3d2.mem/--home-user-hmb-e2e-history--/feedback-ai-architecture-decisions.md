---
name: feedback-ai-architecture-decisions
title: AI架构关键决策
description: 苏格拉底与小萤必须使用独立记忆/对话历史，仅共享全局知识
type: feedback
importance: 7
created: 1791604457312
updated: 1791604457312
---

**决策**：苏格拉底和小萤采用**独立记忆系统**，而非共享对话历史。

**Why**：曾尝试通过提示词强化角色边界，但苏格拉底仍无法可靠识别'此刻是谁在提问'（用户 vs 小萤），导致回应风格混淆（从引导者滑向被引导者）。根因是同一 user_id 下混合了多种对话场景，模型仅凭提示词无法稳定区分。

**How to apply**：
- 为苏格拉底和小萤分别创建独立的对话历史存储目录（如 `conversations_socrates/` 和 `conversations_xiaoying/`）。
- 两者可共享全局知识，但对话历史与角色认知必须隔离。
- 不要依赖单纯修改 System Prompt 来解决角色混淆问题。
