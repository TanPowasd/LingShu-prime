---
name: catgirl-protocol-memory-api-endpoints
title: 猫娘计划记忆服务端点约定
description: 记录单元新增 /memory/all 全量读取端点；/memory/search 空查询不返回条目
type: project
importance: 6
created: 1791605590474
updated: 1791605590474
---

## 记忆服务端点约定

- `/memory/search`：**查询为空时不返回任何条目**，因此无法用于获取全量数据。
- `/memory/all?layer=<layer>`：新增于记录单元，返回指定层级的全部记忆数据（供其他单元只读访问），返回结构为 `{"<layer>": [...]}`。仅记录单元（role=record）可提供。
- 记录单元默认端口 8001，对外统一代理端口 8000。

## 已知语义检索问题

情境层（叙事性用户对话）与知识层（结构化协议描述）之间的向量语义相似度天然偏低，纯语义检索难以建立跨层关联（用情境查询搜不到知识层条目，即便阈值降到 0.1）。跨层连接需由联想机制主动建立，不能依赖语义检索阈值。
