---
name: ref-gliding-horse
title: 参考项目：流马（Gliding Horse）
description: Rust构建的AI Agent操作系统，图结构记忆验证了协议知识层结构合理性
type: reference
importance: 5
created: 1791605622888
updated: 1791605622888
---

**流马（Gliding Horse）**：用 Rust 构建的 AI Agent 操作系统。GitHub: https://github.com/doiito/gliding_horse

- **核心机制**：动态 PDCA 调度、JSON-LD 语义图谱、代码级系统调用门，运行时硬性约束 Agent 行为
- **关键贡献**：将 Agent 记忆从线性/表格存储迁移到**图结构存储**（L2 Blackboard 使用 JSON-LD 语义图谱）
- **与协议的关系**：在工程层面验证了协议框架中知识层 + 条件空间识别卡的结构合理性；PDCA 闭环与协议3.10节自迭代闭环结构同构

荣的评估：图结构记忆是很好的进步，但**下一代结构应为「自分型的图结构」**——节点自发生成、边自主建立、记忆图谱随交互自然演化，而非外部预定义的固定图谱。
