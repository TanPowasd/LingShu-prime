---
name: codex-catgirl-role-division
title: Codex 与猫娘的角色分工
description: Codex 是执行器（本地沙箱读写文件/执行命令），猫娘是大脑（生成指令），Codex 需要外部 LLM 提供推理。
type: project
importance: 8
created: 1791605588102
updated: 1791605588102
---

Codex CLI 本质是**本地代理 = LLM + 本地执行引擎**，自身不含 LLM：

- Codex 负责：接收指令 → 调用 LLM 理解意图 → 在本地沙箱执行 shell/读写文件/改代码
- 猫娘负责：作为大脑生成可执行的命令与指令（规划层）

因此猫娘需要知道两件事：Codex 的**通信格式**和**可用命令集**。Codex 默认沙箱为 `read-only`（只能读不能写），需要写权限时用 `--dangerously-bypass-approvals-and-sandbox` 或配置 `workspace-write`。

**Why:** 之前误以为 Codex 自带 LLM 或能直接反向调用猫娘，导致集成思路跑偏。
**How to apply:** 面向 Codex 的回复要输出结构化可执行指令，而不是纯自然语言。
