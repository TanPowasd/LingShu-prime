---
name: feedback-codegraph-adapter-quirks
title: CodeGraph 适配器已知坑（Windows）
description: CodeGraphAdapter 在 Windows 下的 PATH 检测与数据库表名/列名不匹配问题。
type: feedback
created: 1791605586141
updated: 1791605586141
---

在 Windows 上集成 CodeGraph 时反复踩到的坑：

1. **命令检测失败**：`_check_availability` 用 `subprocess` 找 `codegraph` 会失败，因为 npm 全局包路径（`C:\Users\FuRongJun\AppData\Roaming\npm`）不在 PATH 中。应改用 `shutil.which` 或显式路径。
2. **表名不匹配**：适配器期望 `symbols` 表，实际是 `nodes` 表。
3. **列名不匹配**：期望 `line_start`/`line_end`，实际是 `start_line`/`end_line`。
4. **索引未构建**：`codegraph init` 后还需运行 `codegraph index`，否则数据库无表。
5. Windows 无 `sqlite3` CLI，需用 Python 的 `sqlite3` 模块检查数据库。

**Why:** 这些错误都会以 404/500 或 `sqlite3.OperationalError` 形式出现，容易被误判为逻辑 bug。
**How to apply:** 改动 CodeGraph 相关代码前，先用 Python 打印 `PRAGMA table_info(nodes)` 和表清单确认实际 schema，再写 SQL。
