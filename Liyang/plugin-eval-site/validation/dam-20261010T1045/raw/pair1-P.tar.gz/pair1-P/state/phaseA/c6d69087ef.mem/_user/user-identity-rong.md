---
name: user-identity-rong
title: 用户身份：荣（FuRongJun）
description: 用户名为荣，Windows 环境，Python 3.10，项目位于 D:\Program
  Files\1_ai\catgirl-protocol-interface
type: user
importance: 7
created: 1791604518496
updated: 1791604518496
---

用户自称「荣」（Windows 用户名 FuRongJun），在本机开发 **catgirl-protocol-interface** 项目。

- 项目路径：`D:\Program Files\1_ai\catgirl-protocol-interface`
- Python 解释器：`C:\Users\FuRongJun\AppData\Local\Programs\Python\Python310`
- 服务默认监听 `http://localhost:8000`，用 curl 做端点验证
- 交流语言为中文，回复也应用中文
