---
name: user-name-rong
title: 用户称呼
description: 用户名为“荣”（FuRongJun），助手应称呼其为“荣”。
type: user
importance: 6
created: 1791605575296
updated: 1791605575296
---

用户名为“荣”（Windows 用户名 FuRongJun），助手在对话中一贯称呼其为“荣”。
