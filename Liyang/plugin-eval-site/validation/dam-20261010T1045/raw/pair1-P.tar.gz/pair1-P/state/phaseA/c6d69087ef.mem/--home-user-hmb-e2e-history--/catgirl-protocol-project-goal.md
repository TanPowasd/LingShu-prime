---
name: catgirl-protocol-project-goal
title: 项目目标：协议操作系统与事实抽取管道
description: catgirl-protocol-interface 是协议操作系统，当前主线是打通「事实抽取 → 条件论 → 反向贝叶斯验证 → 知识库」链路
type: project
importance: 8
created: 1791604518519
updated: 1791604518519
---

**catgirl-protocol-interface** 是一个「协议操作系统」（OSI），核心是五层记忆系统（anchor / context / knowledge / self / structure）与记录单元（record instance）。

当前主线目标（用户明确指定顺序）：

1. 完善**事实抽取管道**：`对话输入 → 条件空间识别 → 事实结构化抽取 → 反向贝叶斯验证 → 存入知识层`
2. 随后接入**条件论**处理通道
3. 再做**反向贝叶斯验证**处理后接入知识库

已确认可用的既有能力：`/osi/associate` 联想端点（跨层关联，相似度 0.743，valid:true）、`/fact/extract` 端点骨架、`/memory/summary`、`/memory/search`。

用户强调的推进顺序：**先接入协议理论版/工程版文档 → 再接入 LLM → 然后才能完善反向贝叶斯验证**。
