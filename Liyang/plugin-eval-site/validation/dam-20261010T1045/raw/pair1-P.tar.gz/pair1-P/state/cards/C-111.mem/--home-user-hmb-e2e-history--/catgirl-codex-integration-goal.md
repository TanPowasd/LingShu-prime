---
name: catgirl-codex-integration-goal
title: 猫娘项目接入 Codex 的演进目标
description: 先用 Codex 提供网页搜索和代码修改，跑通闭环后再用猫娘原生模块逐步替代，最终移除 Codex 依赖。
type: project
importance: 8
created: 1791605591801
updated: 1791605591801
---

猫娘项目（catgirl-protocol-interface）接入 Codex CLI 的目标是**先用起来，再逐步替代**：

1. 阶段1（当前）：猫娘 → Codex（网页搜索 + 代码修改），跑通“意图→搜索→修改→验证”闭环
2. 阶段2：猫娘 → Codex（代码修改）+ 原生 SearchExecutor（搜索）
3. 阶段3：猫娘 → 原生操作引擎（代码修改）+ 原生 SearchExecutor
4. 阶段4：完全移除 Codex 依赖

**Why:** 猫娘目前的自我学习和代码修改能力尚不完善，先用现成的 Codex 赋能，避免重复造轮子。
**How to apply:** 讨论 Codex 集成时按此演进路径推进，不要试图把 Codex 改造成猫娘的一部分，也不要让 Codex 反向调用猫娘作为 LLM 替代。
