---
name: project-spacetime-memory-engine
title: 项目：时空记忆引擎（spacetime-memory-engine）
description: 位于 D:\Program Files\2_ai\spacetime-memory-engine，Flask 服务端口 8899，集成
  CodeGraph 代码域探针。
type: project
created: 1791605586794
updated: 1791605586794
---

项目路径：`D:\Program Files\2_ai\spacetime-memory-engine`

- 主程序：`spacetime-memory-engine.py`（含 `SpacetimeMemoryEngine`、`CodeGraphAdapter`、`WebInterface._setup_routes`）
- Flask 服务监听 `http://localhost:8899`
- 端点 `/api/codegraph/sync`（POST）用于将 CodeGraph 索引同步进时空图
- 依赖外部工具 CodeGraph（npm 全局包 `@colbymchenry/codegraph`），索引数据库位于 `.codegraph/codegraph.db`
- 运行环境：Windows，Python 3.10，venv

注意：CodeGraph 的 SQLite 表结构以 `nodes` / `edges` 为核心（不是 `symbols`），字段用 `start_line` / `end_line`（不是 `line_start` / `line_end`）。
