---
name: user-role-and-project
title: 用户身份与项目背景
description: 用户是独立开发者，正在构建以'消灭信息差'为核心的AI教育系统（苏格拉底+小萤）
type: user
importance: 9
created: 1791605589649
updated: 1791605589649
---

用户（furongjun）是一位独立开发者/理论构建者，正在主导一个名为'共信主义'（Common Trust）的AI教育理论项目。

核心工作：
- 构建两个AI角色：**苏格拉底**（教育引导者AI，使命是消灭信息差）和**小萤**（8岁乡村小学生AI，向老师学习）。
- 技术栈：Python + FastAPI 后端，DeepSeek API（deepseek-reasoner 模型），前端为 index.html。
- 已实现功能：记忆系统、梦境机制、孤独反思、社交网络、对抗训练。
- 已通过内网穿透（使用 **SakuraFrp**，非 ngrok）将系统分享给朋友测试。

用户的深层身份：理论探索者，从'减少信息差是智能的必要条件'这一假设出发，推导出完整智能系统理论。
