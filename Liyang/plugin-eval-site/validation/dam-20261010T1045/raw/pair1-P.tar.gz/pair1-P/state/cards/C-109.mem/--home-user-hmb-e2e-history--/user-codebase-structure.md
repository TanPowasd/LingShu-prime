---
name: user-codebase-structure
title: 小萤代码库结构与已知陷阱
description: 含main.py、训练脚本、xiaoying_life.py、xiaoying_social.py；ExtendedXiaoyingLife.memories是dict列表而非Memory对象
type: project
importance: 6
created: 1791605583334
updated: 1791605583334
---

小萤系统代码库主要文件：
- `main.py`：FastAPI主程序，含chat接口，区分socrates与xiaoying两种模式
- 训练脚本
- `xiaoying_life.py`：XiaoyingLife类，memories是**Memory对象列表**（有.importance属性）
- `xiaoying_social.py`：ExtendedXiaoyingLife类，memories是**dict字典列表**（需用['importance']访问）

**已知陷阱（修复时注意）**：
1. ExtendedXiaoyingLife.memories元素是dict，误用`m.importance`会报`'dict' object has no attribute 'importance'`，须用`m['importance']`或`m.get('importance')`。
2. `socrates`分支曾因未初始化`xiaoying = ExtendedXiaoyingLife(user_id)`就调用`xiaoying.format_prompt_context(...)`，导致`UnboundLocalError: local variable 'xiaoying' referenced before assignment`。两个模式都需初始化实例。

运行环境：Python 3.7，Windows（路径 c:\users\furongjun\...），uvicorn + FastAPI + starlette。
