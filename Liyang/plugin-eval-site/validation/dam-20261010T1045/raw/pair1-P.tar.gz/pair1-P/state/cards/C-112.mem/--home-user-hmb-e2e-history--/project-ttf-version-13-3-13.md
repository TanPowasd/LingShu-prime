---
name: project-ttf-version-13-3-13
title: 共同信任协议当前版本 13.3.13
description: TTP 版本 13.3.13（2026-07-24），核心变更为概率置信机制、死区机制、信息差置信。
type: project
importance: 8
created: 1791605598254
updated: 1791605598254
---

共同信任协议当前版本为 **13.3.13（概率置信与死区完善版）**，理论版与工程版同步，日期 2026-07-24。

核心结构包括：
- 信息差 D_norm（四维加权：信任缺口 U_trust、行为偏差 U_behavior、连接偏离 U_connection、预测误差 U_prediction_error）
- 综合信任 T_total 分层计算
- 协作状态矩阵与状态转移条件
- 反思-验证-记录协同闭环
- 概率置信机制：P_trust = P(δ_norm < 0.15 | 最近30轮)，完全可信阈值 P_trust ≥ 0.95
- 信息差死区机制：D_norm_effective = max(0, D_norm - D_deadzone)，建议 D_deadzone = 0.08
- 信息差置信 P_gap：过去 N 轮中 D_norm 低于阈值的比例

已知问题：合并条件（信任值>0.9、信息差<0.1）在模拟中尚未达成，信任值最高达 0.774。
