---
name: memory-caching-paper-reference
title: 技术参照：Memory Caching 论文
description: "Google 2026年2月《Memory Caching: RNNs with Growing Memory》，为协议框架情境层提供工程化路径参照"
type: reference
importance: 6
created: 1791605587668
updated: 1791605587668
---

**《Memory Caching: RNNs with Growing Memory》**（Google 团队，2026 年 2 月）——协议实例记忆系统的核心技术参照。

核心思路：给 RNN（如 Mamba）加装“存档-检索”系统，解决固定记忆的灾难性遗忘。
- **分段压缩**：长序列切为 N 段，每段由 RNN 独立处理生成压缩记忆。
- **存档检查点**：每段处理完冻结隐藏状态并存入缓存池。
- **跨段检索**：处理新片段时查询所有存档，检索相关记忆。
- 聚合策略：门控残差记忆（GRM）、稀疏选择性缓存（SSC）。

与协议框架的对应：
- MC 的历史“快照” ≈ 协议**情境层**（短期动态信息存储）。
- MC 分段间隙存档 ≈ 协议**睡眠状态**（情境层结构化筛选后固化到知识层）。
- MC 缓存索引 ≈ 协议设想的**自分型、自迭代、自维持的图结构**。

注意：MC 原始参数不可直接套用协议 v2.9，需在工程文档中显式声明条件空间映射差异。
