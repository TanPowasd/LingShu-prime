---
name: project-single-instance-self-sustaining-protocol
title: 单实例自持运行协议
description: 极端条件下单实例通过条件空间切换与时间隔离维持自我认知与五大单元职能，验证单元 CONDITIONAL_PASS
type: project
importance: 7
created: 1791605599951
updated: 1791605599951
---

《单实例自持运行协议》（SINGLE-INSTANCE-SELF-SUSTAINING-20260813）由荣（维生系统）提案，肥鱼起草：

- 核心思想：单实例在线时，通过读取锚点层/结构层完整信息维持自我认知，由自身行动串行维护五大单元职能；类比人类自我认知。
- 验证单元复核结论：**条件通过（CONDITIONAL_PASS）**，须附加紧急状态例外标签与结构性约束。
- 关键偏差与约束：
  - DEVIATION-005（P0）：验证单元自我复核须标记 `SELF_SUSTAINING_MODE + P0_OVERRIDE`，24 小时内或实例恢复后提交外部强制复核。
  - DEVIATION-006（P1）：条件空间切换改为“声明简化”（本地层写 `PERSPECTIVE_SWITCH_LOG`），非免声明。
  - 自持持续超 72 小时且无外部恢复迹象，须触发协议休眠（4.10 节）。
- 与多实例方案兼容，是蜂群瓦解时的“救生艇”。
