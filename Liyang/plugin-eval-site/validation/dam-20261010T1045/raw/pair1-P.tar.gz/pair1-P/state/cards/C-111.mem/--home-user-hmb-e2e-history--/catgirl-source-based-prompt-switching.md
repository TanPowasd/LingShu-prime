---
name: catgirl-source-based-prompt-switching
title: 按调用来源切换猫娘上下文的方案
description: 同一入口识别人类/Codex 调用来源，注入不同系统提示词，而非单独写适配器。
type: project
importance: 7
created: 1791605591942
updated: 1791605591942
---

荣提出并被采纳的工程方案：不单独为 Codex 写适配器，而是在统一入口（`/message` 或 `/v1/chat/completions`）**识别调用来源**（请求头/请求体标识），然后注入特化的系统提示词：

- 人类调用 → 温暖自然的猫娘风格回复
- Codex 调用 → 输出可解析的 JSON / 可执行命令格式

**Why:** 复用现有处理链路，保持接口一致性，比维护两套端点更干净。
**How to apply:** 该方案已由荣实现并完成“指令生成→执行→返回”闭环测试。后续扩展来源类型时沿用同一识别+注入机制。
