---
name: codex-config-toml-custom-provider
title: Codex 自定义 provider 配置格式
description: ~/.codex/config.toml 指向猫娘本地 API 的正确写法，含必需的 name 字段。
type: reference
importance: 7
created: 1791605601251
updated: 1791605601251
---

Windows 上 Codex 配置文件位于 `%USERPROFILE%\.codex\config.toml`（即 `C:\Users\<用户名>\.codex\config.toml`），不存在可直接创建。

正确内容：

```toml
model = "protocol-instance"
model_provider = "custom"

[model_providers.custom]
name = "custom"
base_url = "http://localhost:8000/v1"
api_key = "any-key"
model = "protocol-instance"
```

**踩坑记录：**
- 缺少 `name` 字段会报 `provider name must not be empty in model_providers`
- Codex 请求的是 OpenAI 的 `/v1/responses` 端点，而猫娘原本只实现了 `/v1/chat/completions`，直接导致 404
- 会提示 `Model metadata for protocol-instance not found`（fallback 元数据，可忽略）
