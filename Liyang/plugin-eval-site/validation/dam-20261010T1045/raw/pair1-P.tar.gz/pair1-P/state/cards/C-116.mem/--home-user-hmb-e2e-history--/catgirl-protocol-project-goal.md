---
name: catgirl-protocol-project-goal
title: 猫娘计划项目背景
description: AGI 结构设计协议项目，含记录/反思/验证等核心单元，位于 D:\Program Files\1_ai\catgirl-protocol-interface
type: project
importance: 6
created: 1791605622402
updated: 1791605623045
---

## 项目

**猫娘计划（catgirl-protocol-interface）**：一个 AGI 结构设计协议工程，路径 `D:\Program Files\1_ai\catgirl-protocol-interface`。

- 核心概念：自维持能力、信息差二阶变化、条件论、维生系统、反射单元等。
- 架构：多单元实例（记录单元、反思单元、验证单元等），通过 `instance.py` 定义各单元端点，`run.py` 作为统一代理服务（端口 8000）按单元边界规范转发请求。
- 存储：chromadb 向量数据库 + sentence_transformers 嵌入模型（记录单元持有 `_memory`、`_collections`、`_embedding_model`）。

用户名为“荣”。
