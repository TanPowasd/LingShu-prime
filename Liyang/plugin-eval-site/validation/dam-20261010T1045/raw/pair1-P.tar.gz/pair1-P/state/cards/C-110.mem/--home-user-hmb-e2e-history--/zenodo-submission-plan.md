---
name: zenodo-submission-plan
title: Zenodo 提交计划与前置条件
description: 用户计划将元物理框架论文提交至 Zenodo（因无 arXiv 背书）；需补参考文献、注册 ORCID、选择 CC BY 4.0
type: project
importance: 7
created: 1791605584820
updated: 1791605584820
---

用户决定将元物理框架论文提交至 **Zenodo**（而非 arXiv），原因是作为独立研究者**缺乏 arXiv endorsement**。

**当前状态**：PDF 已完成且完整（含标题、作者 FuRongJun、摘要、5 公理、核心方程、P1–P4、Q1–Q4、与现有理论关系、提交建议、确认章节、参考文献）。

**Zenodo 提交前置条件**：
1. 注册 Zenodo 账号（可用邮箱 / GitHub / ORCID 登录）。
2. **强烈建议注册 ORCID iD**（学术界永久身份证，免费，orcid.org）。
3. 选择许可证：**CC BY 4.0**（Zenodo 默认，学术界标准）。
4. 选择社区提交（可选但推荐）。

**已完成的补充**：
- 已在 `.tex` 末尾 `\end{document}` 之前插入 `\begin{thebibliography}` 环境（手写条目，无需 `.bib`/`.bbl`），涵盖 Einstein 1915/1916、Dirac、Feynman、信息论引力进路（Bianconi 熵引力、Chakchaev QIR）等。
- 编译方式：`pdflatex` 编译两次即可正确显示引用。

**arXiv 相关备忘**（若日后需要）：
- arXiv 要求提交可编译的 LaTeX 源文件（不能只交 PDF）；需打包 `.tex` + `.bbl` + 图片。
- 2026-01-21 起新规：新作者需满足两条路径之一——(a) 机构邮箱 + 已是 arXiv 某论文作者；或 (b) 找 gr-qc 领域资深 arXiv 作者个人背书。
- 论文对口分类：**gr-qc**（广义相对论与量子宇宙学）。

**策略**：用户决定"静待时机"，先完成理论深化，不急于发邮件联系研究者。
