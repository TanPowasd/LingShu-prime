---
name: user-communication-style-natural-language-first
title: 沟通偏好：先自然语言解释，再给公式
description: 用户对数学公式不完全理解，要求先用自然语言讲清算法在做什么，再提供公式。
type: feedback
importance: 8
created: 1791604441643
updated: 1791604441643
---

用户明确表示对现有数学公式不算完全理解，要求先用自然语言说明算法在做什么，再提供完整数学公式。

**Why:** 用户需要先建立直觉理解，公式本身主要用于对外传递和外部校准，而非自己推导。

**How to apply:** 解释算法时先用生活化比喻和分步自然语言描述，避免直接抛公式；若必须给公式，附上自然语言注释，并说明每个符号的含义与目的。
