---
name: memory-layers-type-unification
title: MemorySystem._layers 必须统一为 MemoryEntry
description: 反复出现的 AttributeError 根因是 _layers 混存 dict/str/MemoryEntry，应统一数据结构而非到处加类型防御
type: feedback
importance: 7
created: 1791604518561
updated: 1791604518561
---

`MemorySystem._layers` 中的条目来源不一（`record_instance._memory` 从磁盘加载的是 dict，`store()` 写入的是 `MemoryEntry`，个别情况下混入 str），导致 `entry.content` / `entry.get()` 反复抛 `AttributeError`。

**Why:** 用户在同一个错误第三次出现时明确指出「你应该进入反思流程了」——他不接受在调用点反复打补丁，要求找到结构层根因。

**How to apply:** 遇到此类类型错误时，先统一数据结构（所有 `_layers` 条目规范为 `MemoryEntry`），而不是在每个访问点加 `hasattr` / `isinstance` 防御。若同一错误重复出现两次以上，主动进入反思流程，说明根因与结构性修正方案，而非继续局部修补。
