---
name: feedback-github-repo-protection
title: 仓库权限设置：保护 main 分支
description: 用户不希望他人随意改代码，需通过分支保护规则限制直接推送 main。
type: feedback
importance: 5
created: 1791603695292
updated: 1791603695292
---

用户对 GitHub 协作权限不熟悉，明确表示「不希望其他人随意改代码」。

**Why:** 公开仓库任何人可 fork/提 Issue/PR，但默认只有所有者能直接 push；用户此前已误将 Zcode-肥鱼加为 collaborator 授予写权限。

**How to apply:** 建议通过 Settings → Branches 添加分支保护规则（pattern `main`），勾选 Require a pull request before merging 及 Require approvals；保留 Issues/Pull requests 作为正常协作渠道。若需收回权限，从 Settings → Collaborators 移除协作者。
