---
name: catgirl-codex-role-division
title: 猫娘与 Codex 的角色分工
description: Codex 是执行器，猫娘是大脑：猫娘生成命令，Codex 在本地沙箱执行并返回结果
type: project
importance: 8
created: 1791603688066
updated: 1791603688066
---

## 角色定位

- **猫娘（大脑）**：理解意图、生成可执行的代码和命令
- **Codex（执行器）**：接收命令 → 在本地沙箱执行 → 返回结果

Codex 本身不产生意图，也不自带 LLM，它需要一个外部 LLM 端点来理解指令、规划动作。

**关键结论：** 猫娘需要知道两件事——Codex 的通信格式，以及 Codex 可用的命令集（文件读写、目录列表、代码修改等）。

**Why:** 用户经过多轮讨论确认了这个分工，这是整个集成方案的基础认知。

**How to apply:** 设计猫娘与 Codex 交互时，猫娘侧负责生成结构化指令，不要期望 Codex 自行推断意图。
