---
name: catgirl-project-paths
title: 猫娘项目关键路径与运行方式
description: 项目位于 D:\Program Files\2_ai\catgirl-protocol-interface，服务通过 python
  run.py 启动在 8000 端口
type: reference
importance: 5
created: 1791603704286
updated: 1791603704286
---

## 关键路径

- 项目根目录：`D:\Program Files\2_ai\catgirl-protocol-interface`
- 使用 venv 虚拟环境
- 服务入口：`run_main.py`（Flask 应用，含路由注册）
- 猫娘本地 API 监听：`http://localhost:8000/v1`
- 启动命令：`python run.py`

## 测试命令

```bash
codex exec --approve-for-me -C "D:\Program Files\2_ai\catgirl-protocol-interface" "列出项目的主要目录结构"
```

**踩坑记录：** Windows CMD 下中文提示词需用引号包裹，否则 Codex 会报 `unexpected argument`；必要时用 `--` 分隔选项与提示词。
