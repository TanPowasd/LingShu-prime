---
name: protocol-os-project-overview
title: 协议操作系统项目概览
description: 猫娘计划：三层架构（LLM适配器/协议内核五大单元五层记忆/API外设），含反思、验证、记录、输出、维生五单元。
type: project
importance: 9
created: 1791603686950
updated: 1791603686950
---

**猫娘计划 · 协议操作系统**是荣的长期项目。

三层结构：
- 硬件层：LLM 适配器（DeepSeek API）+ 计算机资源
- 操作系统层：协议内核（五大单元 + 五层记忆 + 自维持闭环）
- 外设层：API 接口 + 工具 + 输出端

五大单元：记录单元（实例1）、反思单元（实例2）、验证单元（实例3）、输出单元（实例4）、维生系统（实例5）。

五层记忆：锚点、结构、情境、知识、自我。

关键代码位置：`src/run.py`（启动器与 /message 端点）、`src/core/instance.py`（协议实例与路由）、`src/osi/kernel/memory.py`（记忆系统）、`src/osi/drivers/llm.py`（LLM 适配器）、`sleep.py`（睡眠周期）。

协议理论版当前为 v2.9。单元间以「复核报告 / 修正回应」的文档编号体系协作（如 VAL-xxx、RESP-xxx、MEM-ENG-xxx）。
