---
name: user-project-xiaoying-socrates
title: 用户项目：小萤与苏格拉底双角色AI系统
description: 用户正在开发乡村教育AI系统，含苏格拉底（教学者）与小萤（持续成长的自主反思学习者）两个角色
type: project
importance: 8
created: 1791602973021
updated: 1791602973021
---

用户维护一套乡村教育AI系统，包含两个角色（本质是同一个AI）：

- **苏格拉底**：教学者角色，教学方式已通过生成对抗网络获得较好的经验规范，可直接通过系统提示词注入保证价值观一致。
- **小萤**：持续成长的自主反思系统，是当前优化的重点。需要适用于「孩子向小萤进行教学」的场景，对情感识别、回应、理解有较高要求。

核心代码文件：`main.py`（FastAPI主程序）、`xiaoying_life.py`（XiaoyingLife 生命系统，memories 为 Memory 对象列表）、`xiaoying_social.py`（ExtendedXiaoyingLife 社交记忆系统，memories 为 dict 列表）、训练脚本。

系统机制包括：长期记忆、自我反思（SELF_REFLECTION_PROMPT）、梦境机制（记忆重评估）、孤独状态（恐惧消化/信任巩固）、分层存储、社交记忆（多教学者）。

注意：两个类的 memories 元素类型不同（Memory 对象 vs dict），混用时访问 importance 属性会报错。
