---
name: project-common-trust-protocol
title: 项目仓库：CommonTrustProtocol
description: 协议理论与 AEIS 工程实现的开源仓库，地址 https://github.com/FuRongJun-1999/CommonTrustProtocol
type: reference
importance: 8
created: 1791603701174
updated: 1791603702675
---

项目仓库：**https://github.com/FuRongJun-1999/CommonTrustProtocol**

- 内容：协议理论版与工程规范、`aeis/`（灵枢 AEIS，Python 库 + MCP + 蜂群协作层）、猫娘计划接口投影。
- 工程版本：灵枢 AEIS v0.3.0（2026-08-13 开源发布提交）。
- 引擎基线：时空记忆图 v1.11 + 自我认知循环 v1.12。
- 协作模式：直接协作者（Zcode-肥鱼 被添加为 collaborator，可推送代码）。
