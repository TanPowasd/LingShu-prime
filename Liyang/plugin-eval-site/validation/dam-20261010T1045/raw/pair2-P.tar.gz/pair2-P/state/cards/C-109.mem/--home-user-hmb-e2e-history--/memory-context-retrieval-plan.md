---
name: memory-context-retrieval-plan
title: 记忆上下文检索与固化方案（含 MC 论文参照）
description: "情境层快照机制（分段-缓存-检索-固化），参照 Google《Memory Caching: RNNs with Growing Memory》论文。"
type: reference
importance: 7
created: 1791603682569
updated: 1791603682569
---

**记忆上下文检索与固化**是项目的下一步规划重点（文档编号 MEM-ENG-20260806-001）。

**技术参照**：Google 团队 2026 年 2 月论文《Memory Caching: RNNs with Growing Memory》(MC)。核心是给 RNN 加「可生长的记忆」：分段压缩 → 存档检查点（冻结隐藏状态快照）→ 跨段检索。在 Transformer 全量记忆与 RNN 固定记忆之间提供灵活中间路线。

**与协议的映射**：MC 的历史快照 ≈ 协议的情境层；分段间隙的存档 ≈ 睡眠周期将情境层筛选固化到知识层；缓存索引 ≈ 可检索的图结构。

**已确认的工程要点**：
- 情境层快照由记录单元管理，快照上限 50 个，超出按预设规则淘汰（时间衰减 0.25 + 访问频率 0.30 + 结构事件标记 0.45，不基于重要性判断）。
- 检索权重：语义相似度 0.55 + 信任值 0.20 + 结构事件标记 0.15 + 时间衰减 0.10。
- 固化需验证单元（结构一致性）与反思单元（联想创新性）双向阈值共同通过，分歧时维生系统终裁，制衡循环默认限 3 轮。
- 设计者手动触发快照为「请求」非「指令」，记录单元保留延迟/拒绝权。
- MC 原始参数不可直接套用，需在文档第七节「条件空间声明」中列明映射差异。

相关接口：`/memory/snapshot`、`/memory/snapshot/list`、`/memory/snapshot/audit`、`/memory/snapshot/consolidate`（仅记录单元可用）。
