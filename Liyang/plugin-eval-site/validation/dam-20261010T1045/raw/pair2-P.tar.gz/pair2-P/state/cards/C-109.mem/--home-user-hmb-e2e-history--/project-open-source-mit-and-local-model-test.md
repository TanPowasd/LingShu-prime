---
name: project-open-source-mit-and-local-model-test
title: 开源许可证 MIT 与千问7B本地模型实测计划
description: 项目采用 MIT 许可证；后续开源时做成本对比（纯云端 vs 本地 vs 混合），并用千问7B实测验证。
type: project
importance: 7
created: 1791603681623
updated: 1791603681623
---

开源决策与验证计划：

- **许可证**：采用 **MIT**（最大化生态扩散，允许闭源商用）。
- **背景**：DeepSeek API 价格翻倍以上，本地化/离线可运行方案的成本与信任连续性优势凸显。
- **计划**：开源时发布成本对比（A 纯云端 API / B 协议本地推理 / C 协议混合模式），并用**千问 7B** 本地实测效果。
- 对比维度：单次对话成本、长期记忆维护成本、离线可用性、信任/价值观连续性、实例自我认知连续性。
