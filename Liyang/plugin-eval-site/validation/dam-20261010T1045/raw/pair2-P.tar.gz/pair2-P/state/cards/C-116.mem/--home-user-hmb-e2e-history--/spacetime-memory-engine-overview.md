---
name: spacetime-memory-engine-overview
title: spacetime-memory-engine 项目概览
description: 时空记忆引擎：Flask 服务（端口 8899）+ 时空图存储 + CodeGraph 代码域探针
type: project
importance: 7
created: 1791603707213
updated: 1791603707213
---

`D:\Program Files\2_ai\spacetime-memory-engine` 是协议框架的工程实现。

- 主入口 `spacetime-memory-engine.py`，内含 `SpacetimeMemoryEngine`、`WebInterface`（Flask，`_setup_routes` 注册路由）、`CodeGraphAdapter`。
- Web 服务监听 `http://localhost:8899`。
- 已实现端点：`POST /api/codegraph/sync`（调用 `self.codegraph.sync_to_spacetime(self.engine)`）。
- CodeGraph 用于把代码结构（节点/边）同步进时空图，作为「代码域探针」。
- 用户的使用习惯：喜欢在项目目录下写临时脚本（如 `test.py`）直接跑接口验证。
