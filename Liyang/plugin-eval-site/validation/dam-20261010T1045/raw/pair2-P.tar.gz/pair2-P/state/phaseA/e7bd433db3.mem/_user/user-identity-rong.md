---
name: user-identity-rong
title: 用户身份：荣（FuRongJun）
description: 用户自称/被称为「荣」，Windows 环境，是「智能论/协议框架」的作者与设计者
type: user
importance: 9
created: 1791603026805
updated: 1791603026805
---

- 用户名为荣（Windows 用户目录 `C:\Users\FuRongJun`），助手一贯以「荣」称呼他。
- 他是「智能论 / 协议框架」体系（v3.0 已定稿，v3.1 修订中）的作者与设计者，同时是 `spacetime-memory-engine` 项目的开发者。
- 工作环境：Windows + Python 3.10 + venv，项目路径 `D:\Program Files\2_ai\spacetime-memory-engine`。
- 沟通语言：中文。
