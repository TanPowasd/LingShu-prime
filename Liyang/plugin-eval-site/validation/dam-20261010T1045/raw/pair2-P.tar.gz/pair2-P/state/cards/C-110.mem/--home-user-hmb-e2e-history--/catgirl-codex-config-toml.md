---
name: catgirl-codex-config-toml
title: Codex 指向猫娘的自定义 provider 配置
description: Windows 下 ~/.codex/config.toml 配置 custom provider 指向猫娘本地 API，需含 name 字段
type: reference
importance: 6
created: 1791603688147
updated: 1791603688147
---

## 配置文件位置

Windows：`C:\Users\<用户名>\.codex\config.toml`（即 `~/.codex/config.toml`），文件不存在时直接创建。

## 可用配置

```toml
model = "protocol-instance"
model_provider = "custom"

[model_providers.custom]
name = "custom"
base_url = "http://localhost:8000/v1"
api_key = "any-key"
model = "protocol-instance"
```

**踩坑记录：** `[model_providers.custom]` 下必须有 `name` 字段，否则报错 `provider name must not be empty`。

**注意：** Codex 调用的是 `/v1/responses` 端点，而猫娘原实现只有 `/v1/chat/completions`，直接对接会 404。
