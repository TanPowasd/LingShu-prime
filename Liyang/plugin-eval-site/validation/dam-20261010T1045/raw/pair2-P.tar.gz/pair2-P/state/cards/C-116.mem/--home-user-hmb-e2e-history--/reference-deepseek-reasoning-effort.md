---
name: reference-deepseek-reasoning-effort
title: DeepSeek reasoning_effort 参数控制思维链深度
description: DeepSeek 支持 reasoning_effort 参数（low/medium/high）控制模型内部推理深度，设为 low 可显著加速响应
type: reference
importance: 6
created: 1791603739669
updated: 1791603739669
---

DeepSeek API 支持 `reasoning_effort` 参数（`low` / `medium` / `high`），控制模型生成回复前的内部推理长度。

注意区分两个概念：
- **协议的思维链**：多实例串联（反思→验证→设计者），已关闭；
- **DeepSeek 的 reasoning**：模型内部推理深度，通过 `reasoning_effort` 控制。

本项目在 `src/osi/drivers/llm.py` 的 `LLMAdapter` 中设置 `reasoning_effort="low"`，日志会输出「🧠 推理深度: low」。实测关闭后仍保持较好思考效果，因为协议的认知能力来自结构本身（结构约束、长期记忆检索、条件空间识别、前置价值观过滤、自维持闭环），而非依赖思维链串联。
