---
name: protocol-memory-layer-write-issue
title: 协议文档未成功写入知识层
description: 协议理论版仅在 anchor 层（50390字符），knowledge 层中缺少 protocol_theory_full 等三条协议记录
type: project
importance: 7
created: 1791603739607
updated: 1791603739607
---

实测长期记忆状态：
- `anchor` 层：协议理论版 v2.9 已成功加载（约 50390 字符）；
- `knowledge` 层：**缺少** `protocol_theory_full`、`protocol_engineering_full`、`specialized_values_full` 三条记录，只有对话历史片段和 `fact_extraction` 结果（条件空间识别失败、来源 sleep_cycle）。

根因指向 `run.py` 的 `_initialize_instances()` 中协议写入知识层的逻辑依赖 `self.osi_memory.get_protocol_context("theory")` 等调用，需检查 `MemorySystem.get_protocol_context()` 的返回是否为空或写入失败。

影响：特化价值观无法被记忆检索召回，猫娘回答「特化价值观是什么」时凭空生成而非引用协议定义。
