---
name: codegraph-db-schema
title: CodeGraph 数据库结构与适配要点
description: codegraph.db 实际表为 nodes/edges/files，字段是 start_line/end_line，非
  symbols/line_start
type: reference
importance: 6
created: 1791603682001
updated: 1791603682001
---

CodeGraph 的 SQLite 数据库位于项目下 `.codegraph/codegraph.db`（`codegraph init` + `codegraph index` 生成）。

**实际表**：`schema_versions`, `nodes`, `edges`, `sqlite_sequence`, `files`, `unresolved_refs`, `nodes_fts*`, `name_segment_vocab`, `project_metadata`, `sqlite_stat1`。

**注意**：没有 `symbols` 表——适配器最初按 `symbols` 查询导致 `no such table: symbols`，应改用 `nodes`。

**`nodes` 表字段**：`id, kind, name, qualified_name, file_path, language, start_line, end_line, start_column, end_column, docstring, signature, visibility, is_exported, is_async, is_static, is_abstract, decorators, type_parameters, return_type, updated_at`。

**注意**：行号字段是 `start_line` / `end_line`，不是 `line_start` / `line_end`。

Windows 环境注意：`sqlite3` CLI 不在 PATH，检查表结构请用 `python -c "import sqlite3; ..."`；全局 npm 包（如 codegraph）路径可能不在 `subprocess` 的 PATH 中，`_check_availability` 需用 `shutil.which` 或显式路径。
