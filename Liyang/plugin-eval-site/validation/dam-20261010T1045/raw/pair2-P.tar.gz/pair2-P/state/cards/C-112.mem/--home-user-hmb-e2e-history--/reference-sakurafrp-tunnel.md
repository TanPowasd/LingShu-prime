---
name: reference-sakurafrp-tunnel
title: 内网穿透工具：SakuraFrp
description: 用户使用SakuraFrp进行内网穿透，将本地FastAPI服务（端口8000）暴露至公网
type: reference
importance: 4
created: 1791603694116
updated: 1791603694116
---

用户使用 **SakuraFrp**（https://www.natfrp.com/）进行内网穿透，将本地 FastAPI 服务（端口 8000）暴露到公网供他人访问。

操作流程：
1. 注册登录 natfrp.com
2. 创建隧道：类型 TCP，本地 IP 127.0.0.1，本地端口 8000，选择就近国内节点
3. 下载 Windows 启动器 SakuraFrpLauncher.exe
4. 配置启动器并启动隧道

部署优先级：先内网穿透（让别人能访问），再添加 PWA（提升体验）。
