---
name: catgirl-codex-integration-goal
title: 猫娘接入 Codex 的演进目标
description: 先用 Codex 补齐网页搜索与代码修改能力，跑通闭环后逐步用猫娘原生模块替代并最终移除 Codex
type: project
importance: 8
created: 1791603696747
updated: 1791603696747
---

## 目标路径

猫娘项目当前自我学习与代码修改能力尚未完善，因此先接入 Codex CLI 补齐能力，演进路径为：

1. 阶段1（当前）：猫娘 → Codex（网页搜索 + 代码修改）
2. 阶段2：猫娘 → Codex（代码修改）+ 原生 SearchExecutor（搜索）
3. 阶段3：猫娘 → 原生操作引擎（代码修改）+ 原生 SearchExecutor（搜索）
4. 阶段4：完全移除 Codex 依赖

**Why:** 用户明确纠正过“让 Codex 调用猫娘”的错误方向，目标是先用现成工具跑通闭环，再逐步替代。

**How to apply:** 讨论 Codex 集成方案时，始终以“先跑通、再替代”为原则，不要把 Codex 当作长期依赖来设计架构。
