---
name: external-resources-zenodo-orcid-arxiv
title: 外部资源：Zenodo / ORCID / arXiv 投稿路径
description: 独立研究者投稿的必备资源与关键约束
type: reference
importance: 6
created: 1791603693943
updated: 1791603693943
---

- **Zenodo**：用户认为必要，因为作为独立研究者缺乏学术背书。需注册账号（可用 GitHub/ORCID 登录）、注册 **ORCID iD**（免费，orcid.org）、选择 **CC BY 4.0** 许可证（Zenodo 默认）。可上传 PDF 或 .tex 源文件。
- **arXiv**：
  - 分类 **gr-qc**（广义相对论与量子宇宙学）为最对口分类。
  - **必须提交可编译的 LaTeX 源文件**，仅 PDF 不够。
  - 新规则（2026年1月21日起）背书需满足两条路径之一：① 机构邮箱 + 已是 arXiv 论文作者；② 寻找 gr-qc 领域资深 arXiv 作者个人背书。
  - 若用 `thebibliography` 环境手写参考文献，则无需 .bbl 文件。
- **策略**：用户决定先完成理论深化，暂缓发送邮件联系研究者（Bianconi、Chakchaev、Verlinde 等），静待时机。
