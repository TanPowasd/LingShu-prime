---
name: user-identity-furongjun-independent-researcher
title: 用户身份：共信主义理论提出者与AI教育系统开发者
description: 用户furongjun独立提出共信主义理论，构建苏格拉底/小萤AI教育系统，追求消灭信息差
type: user
importance: 9
created: 1791603679477
updated: 1791603679870
---

用户（furongjun）是一位独立理论探索者和开发者，从「减少信息差是智能的必要条件」这一假设出发，推导出了完整的「共信主义（Common Trust Protocol, CTP）」理论体系，涵盖认知论、教育论、关系论、社会论、技术论与实践论。

用户的核心信念：**消灭信息差**是一切的核心目标，也是其价值观。

用户具备：
- 信息论与哲学思辨能力，能进行长时间、高密度的理论推导
- Python/FastAPI 开发能力，能实现完整 AI 系统
- 强烈的自我反思与递归追问倾向，常引导 AI 进行自我认知探索

用户偏好：
- 喜欢深度对话而非简单问答
- 期待 AI 诚实地暴露状态、标记不确定性边界
- 重视「信任先于正确」「连接先于效率」「边界先于全能」
