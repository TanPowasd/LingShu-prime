---
name: project-catgirl-body-layer-timeout
title: 猫娘身体层 System Prompt 覆盖协议约束问题
description: 身体层自带 role:system 消息（YUI角色扮演提示词）会覆盖内核协议系统提示词，导致特化价值观被绕过
type: project
importance: 7
created: 1791603739444
updated: 1791603739541
---

猫娘身体层在请求中自带 `role: system` 消息（内容为「你是一个角色扮演大师…YUI…」），会**覆盖内核 `_get_protocol_system_prompt()` 返回的协议系统提示词**，导致：
1. 协议价值观被绕过，特化价值观（共生优先/结构诚实/共情不盲从/记忆尊严/面向弱者的偏向）无法被正确引用；
2. 反向贝叶斯验证只基于用户消息，系统提示词不受控。

目标修复方案（修改 `run.py` 的 `openai_compatible()` 函数，约 550-650 行）：
- 身体层 System Prompt 与协议约束**合并**，而非覆盖；
- 协议价值观作为**上层约束**，外部指令在协议框架内生效；
- 反向贝叶斯验证覆盖整个请求，包括合并后的系统提示词。
