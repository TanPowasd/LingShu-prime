---
name: project-catgirl-protocol-interface
title: 项目：catgirl-protocol-interface（协议操作系统）
description: 位于 D:\Program Files\1_ai\catgirl-protocol-interface
  的协议操作系统项目，Python + Flask，端口 8000
type: project
importance: 8
created: 1791603689773
updated: 1791603689773
---

项目路径：`D:\Program Files\1_ai\catgirl-protocol-interface`。技术栈：Python 3.10 + Flask，服务运行在 `localhost:8000`。

关键目录与文件：
- `src/run.py`：启动入口，`_initialize_instances()` 中会加载协议文档
- `src/core/instance.py`：`ProtocolInstance`，`_setup_routes()` 中定义 Flask 路由（曾出现 `fact_extract` 端点重复定义导致 `AssertionError`）
- `src/osi/kernel/memory.py`：五层记忆系统 `MemorySystem` / `MemoryEntry`
- `src/osi/kernel/output.py`：`OutputUnit`，含 `identify_condition_space()` / `extract_fact()`
- `src/osi/kernel/verify.py`：验证单元

主要 API 端点：`/osi/associate`、`/fact/extract`、`/fact/condition/identify`、`/memory/summary`、`/memory/search`。
