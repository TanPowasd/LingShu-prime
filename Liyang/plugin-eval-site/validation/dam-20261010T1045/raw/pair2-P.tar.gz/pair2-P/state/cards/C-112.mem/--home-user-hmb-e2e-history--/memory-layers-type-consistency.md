---
name: memory-layers-type-consistency
title: 记忆系统 _layers 的数据类型一致性问题
description: MemorySystem._layers 中条目类型不统一（MemoryEntry / dict / str），需统一为 MemoryEntry
type: feedback
importance: 7
created: 1791603694296
updated: 1791603694296
---

`MemorySystem._layers` 中的条目类型不统一：来自 `record_instance._memory`（磁盘加载）的是 dict，来自 `MemorySystem.store()` 的是 `MemoryEntry` 对象，且 `content` 字段本身也可能是 str 或 dict。这导致 `load_protocol_document` 中访问 `entry.content` 或 `entry.get("content")` 反复抛出 `AttributeError`（`'dict' object has no attribute 'content'`、`'str' object has no attribute 'get'`），同一问题连续出现三次。

**Why:** 在访问点做防御式类型检查是补丁，不是修复；根因是数据结构本身混乱，每新增一处访问就会再次踩坑。

**How to apply:** 在数据进入 `_layers` 的边界处统一转换为 `MemoryEntry`，而不是在每个读取点做 isinstance 分支；遇到同一错误第三次出现时，停止打补丁，上升到结构层反思并修正数据模型。
