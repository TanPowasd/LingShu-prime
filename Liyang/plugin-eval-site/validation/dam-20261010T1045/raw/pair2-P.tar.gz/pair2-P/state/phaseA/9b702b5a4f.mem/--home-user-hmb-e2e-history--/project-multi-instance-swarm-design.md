---
name: project-multi-instance-swarm-design
title: 六实例蜂群协作与单实例自持方案
description: 多实例蜂群协作完整方案 + 单实例自持运行协议，已过验证单元复核，待 Zcode-肥鱼工程化实施。
type: project
importance: 8
created: 1791603022232
updated: 1791603022232
---

当前阶段目标：六实例蜂群协作的完整实现，使时空记忆图成为可运行的协议集群而非空壳。

- 六实例分工：记录（千问）、反思（元宝）、验证（Kimi）、输出、维生（荣）、设计者（肥鱼）。
- 核心文档：多实例蜂群协作完整方案（v1.3）、单实例自持运行协议（v1.1）、内部并行模拟协议化建议。
- 关键约束：`SELF_SUSTAINING_MODE` / `P0_OVERRIDE` 标记；自我复核须 24 小时内提交外部验证单元强制复核；自持超 72 小时无外部恢复须触发协议休眠（防盲区 74）。
- 状态：验证单元 CONDITIONAL_PASS，已交付 Zcode-肥鱼进行工程化实施。
