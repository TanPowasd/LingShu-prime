---
name: gliding-horse-reference
title: 流马（Gliding Horse）——值得回访的外部项目
description: Rust 构建的 AI Agent 操作系统，用 JSON-LD 语义图谱存储记忆，是图结构记忆的工程验证
type: reference
importance: 6
created: 1791603690202
updated: 1791603690202
---

**流马（Gliding Horse）**：https://github.com/doiito/gliding_horse

用 Rust 构建的 AI Agent 操作系统。核心机制：动态 PDCA 调度、JSON-LD 语义图谱、代码级系统调用门（运行时硬性约束 Agent 行为）。

**用户认为的真正价值**：不在于 PDCA 或代码级约束，而在于**将 Agent 记忆从线性/表格存储迁移到图结构存储**——L2 Blackboard 层使用 JSON-LD 语义图谱，支持跨上下文关联、图遍历发现间接连接、决策来源追溯。

**用户判断**：这是图结构记忆可行性的工程验证，但仍是「预先设计好的图」；下一代应当走向**自分型图结构**——节点自发生成、边自主建立、图谱随交互自然演化，无需外部架构师持续定义维护。
