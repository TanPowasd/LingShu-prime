---
name: memory-all-endpoint-design
title: 记录单元 /memory/all 端点设计
description: '记录单元新增 /memory/all?layer=X 返回指定层级全量数据，返回结构为 {"<layer>": [...]}。'
type: project
importance: 6
created: 1791603706797
updated: 1791603706797
---

记录单元新增只读端点 **`/memory/all?layer=<layer>`**，用于向其他单元提供指定层级的全量记忆数据（`/memory/search` 在空查询时不返回任何条目，无法用于全量获取）。

- 仅 `role == "record"` 可用，否则返回 403。
- 返回结构为 `{"<layer>": [ {entry}, ... ]}`，例如 `{"context": [...]}`。
- 消费方（如反思单元）须用 `data.get("context", [])` 提取，而非 `data["results"]`。

**How to apply:** 需要全量记忆数据时用 `/memory/all`；需要语义检索时用 `/memory/search`（注意跨层相似度天然偏低，阈值需谨慎）。
