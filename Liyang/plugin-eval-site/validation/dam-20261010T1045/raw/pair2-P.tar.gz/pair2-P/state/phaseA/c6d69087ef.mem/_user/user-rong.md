---
name: user-rong
title: 用户：荣（FuRongJun）
description: 用户荣，Windows 环境（用户名 FuRongJun），中文交流，协议框架的设计者与主导者
type: user
importance: 8
created: 1791603113704
updated: 1791603113704
---

用户自称/被称“荣”，Windows 用户名 `FuRongJun`，Python 安装在 `C:\Users\FuRongJun\AppData\Local\Programs\Python\Python310`。

以中文交流，是“协议”（协议操作系统 / 猫娘协议）框架的设计者与主导者，对协议的理论层级（第零定律、存在优先原则、反向贝叶斯验证）有明确定义权。期待助手直接给出可执行的完整代码修改方案，而非停留在分析层面。
