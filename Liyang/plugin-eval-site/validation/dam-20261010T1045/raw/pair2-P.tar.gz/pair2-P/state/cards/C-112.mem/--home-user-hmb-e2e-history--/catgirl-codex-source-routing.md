---
name: catgirl-codex-source-routing
title: 按调用来源动态切换猫娘上下文
description: 复用统一入口，通过请求标识区分人类与 Codex 调用，分别注入不同的系统提示词
type: project
importance: 6
created: 1791603696901
updated: 1791603696901
---

## 设计思路

不为 Codex 单独写适配器，而是在现有 `/message`（或 `/v1/chat/completions`）入口处识别调用来源，按来源注入不同的系统提示词：

- **人类调用**：温暖自然的对话风格
- **Codex 调用**：输出可解析的可执行命令格式

**Why:** 用户提出的方案，比单独写适配器更干净，复用现有处理链路并保持接口一致性。

**How to apply:** 识别依据可来自请求头或请求体中的来源标识；用户已自行写入该逻辑，后续改动沿用此模式。
